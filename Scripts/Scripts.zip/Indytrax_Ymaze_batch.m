%% IndyTrax
% This code tracks animals (e.g. flies) moving within multiple behavioral arenas and computes behavioral output parameters. 
% When running the script, the user can define a folder containing video files (.AVI). All AVI files witin this folder are analyzed 
% and for each video a folder containing all output data will be created in the base directory.
% Arenas must be visually delineated and arranged in a grid for arena detection to work.
% Before running first, please make sure to:
%  - have the circular statistics toolbox installed
%    (https://www.mathworks.com/matlabcentral/fileexchange/10676-circular-statistics-toolbox-directional-statistics)
%  - include the 'cameraParams.mat' for the camera calibration in the working folder
%    (https://www.mathworks.com/help/vision/ref/cameracalibrator-app.html)
%  - set tracking parameters (e.g. arena number,illumination thresholds) under 'user parameters' section
 


%% Get video folder and load camera calibration parameters
clear

dataFolder = uigetdir(); % Get video folder
searchPattern = fullfile(dataFolder, '*.avi'); % Search for AVI files
VideoFiles = dir(searchPattern);
for j = 1 : length(VideoFiles)
    clearvars -except dataFolder searchPattern VideoFiles j
    baseFileName = VideoFiles(j).name;
    fullFileName = fullfile(VideoFiles(j).folder, baseFileName);
   
load('cameraParams.mat') % Load camera calibration parameters

%% User parameters
% set tracking parameters 

ROI_columns=8; % Number of ROI columns
ROI_rows=13; % Number of ROI rows
ROI_sum=ROI_rows*ROI_columns; % Sum of ROIs
ROI_threshold=0.8; % Intensity threshold for detecting ROIs
ROI_area_range_pix=[1500,200000]; % Min and max allowed ROI area in pixels for filtering ROIs by size
ROI_diameter_mm=27; % ROI diameter in mm. This value gets used for real-world-coorinates conversion.
OBJECT_threshold=45; % Intensity threshold for object (animal) detection
downsampledframeratehz=10; % Target framerate for downsampling
Cylinder_inner_diameter_mm=54; % Diameter of the Buridan stimulus cylinder
rotationtheta = pi;       % pi/2 radians = 90 degrees. Every second arena will be rotated by this angular value (in radians).
walkingthreshold=0.8; % Walking threshold in mm/frame
Jumpingthreshold=7; % Jumoing threshold in mm/frame



%% Load video and prepare input data

v = VideoReader(fullFileName); % load video
videoname=baseFileName;
videoname=erase(videoname,'.avi');
mkdir(videoname);

% Create max intensity projection between first and last video frame
frame = read(v,1);
frame = rgb2gray(frame);
[frame,newOrigin] = undistortImage(frame,cameraParams);
referenceframe=frame;
frameend = rgb2gray(read(v,v.NumFrames-1));
[frameend,newOrigin] = undistortImage(frameend,cameraParams);
MaxProj = max(frame,frameend);


[image_height,image_width] = size(frame);
timeall=linspace(0,v.NumFrames/v.FrameRate,v.NumFrames);

x=0;
y=0;
m=0;
c=0;
elapsedTime = 0;
elapsedTimetotal=0;
frameNr=zeros(v.NumFrames,1); 
burst=linspace(0,0,v.NumFrames);






%% Threshold and detect ROIs

frame = read(v,1); % Read first video frame
frame = rgb2gray(frame); % Convert to greyscale
[frame,newOrigin] = undistortImage(frame,cameraParams); % Undistort based on camera calibration parameters
T = adaptthresh(frame, ROI_threshold,'ForegroundPolarity','dark'); % Threshold
BW = imbinarize(frame,T);
BW = imfill(BW,'holes');
BWtemp=BW;
BW = bwareafilt(BW,ROI_area_range_pix); % Filter by ROI area
BW = bwconvhull(BW,'objects');
BW = bwmorph(BW,'thin',1); % Make ROIS smaller for less edge noise. if necessary

ROI_boundaries = bwboundaries(BW,'noholes');
ROI_boundaries_temp=bwboundaries(BWtemp,'noholes');
ROI_Area = regionprops(BWtemp,'Area');
ROI_MajorAxisLength = regionprops(BW,'MajorAxisLength');

% Sort new ROI boundaries
for i=1:ROI_sum
yx_centroid_new{i,1} = mean(ROI_boundaries{i,1});
end
for i=1:ROI_sum
yx_centroid_list_new(i,:)= yx_centroid_new{i,1}; 
end
[yx_centroid_list_new index_new1] = sortrows(yx_centroid_list_new,1);
for i=1:ROI_rows
   [yx_centroid_list_new(1+(i-1)*ROI_columns:i*ROI_columns,:)  index_new2{i}] = sortrows(yx_centroid_list_new(1+(i-1)*ROI_columns:i*ROI_columns,:),2);
end
ROI_boundaries_new_ordered=ROI_boundaries(index_new1,:);
for i=1:ROI_rows
    a{i}=ROI_boundaries_new_ordered(1+(i-1)*ROI_columns:i*ROI_columns,:);
    a2{i}=a{i}(index_new2{1,i},:);
end
ROI_boundaries_new_ordered=[];
for i=1:ROI_rows
ROI_boundaries_new_ordered=vertcat(ROI_boundaries_new_ordered,a2{1,i});
end

for i=1:ROI_sum
MinYX_new{i}=min(cell2mat(ROI_boundaries_new_ordered(i,1)));
MaxYX_new{i}=max(cell2mat(ROI_boundaries_new_ordered(i,1)));
ROI_diameter_pix{i}=max(MaxYX_new{i}-MinYX_new{i});
ROI_diameter_pix_YX{i}=MaxYX_new{i}-MinYX_new{i};
end
ROI_diameter_pix_mean=nanmean(cell2mat(ROI_diameter_pix));

%% Plot ROI detection results

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(1,2,1)
imagesc(BWtemp);
axis equal;
xlim([0 image_width])
ylim([0 image_height])
title(['Thresholded (',num2str(length(ROI_boundaries_temp)),' Areas detected. ','Median Area: ',num2str(nanmedian([ROI_Area.Area])),' pix)'])
% insert scale bar
hold on
plot([0;nanmedian([ROI_MajorAxisLength.MajorAxisLength])], [image_height-2;image_height-2], 'w', 'LineWidth', 4)
hold off
text(nanmedian([ROI_MajorAxisLength.MajorAxisLength])/2,image_height-30, [num2str(ROI_diameter_mm),' mm'], 'HorizontalAlignment','center','FontSize',5,'Color','w')
subplot(1,2,2)
imagesc(BW);
axis equal;
xlim([0 image_width])
ylim([0 image_height])
title(['Size-filtered (',num2str(length(ROI_boundaries)),' Areas detected.',')'])
% insert scale bar
hold on
plot([0;nanmedian([ROI_MajorAxisLength.MajorAxisLength])], [image_height-2;image_height-2], 'w', 'LineWidth', 4)
text(nanmedian([ROI_MajorAxisLength.MajorAxisLength])/2,image_height-30, [num2str(ROI_diameter_mm),' mm'], 'HorizontalAlignment','center','FontSize',5,'Color','w')
for i=1:ROI_sum
line(ROI_boundaries_new_ordered{i,1}(:,2),ROI_boundaries_new_ordered{i,1}(:,1),'LineWidth',1,'Color','k')  
end
for i=1:ROI_sum
text(yx_centroid_list_new(i,2),yx_centroid_list_new(i,1),num2str(i), 'HorizontalAlignment','center','FontSize',8,'Color','k')
end
hold off







%% Detect flies


frame = read(v,1);
frame = rgb2gray(frame);
[frame,newOrigin] = undistortImage(frame,cameraParams);
ImDiff = imabsdiff(frame,MaxProj); % Subtract background
binaryImage1 = ImDiff > OBJECT_threshold; % Threshold animals
binaryImage1 = bwareafilt(binaryImage1,[10 3000]); % Filter detections by size
binaryImage1(~BW) = 0;
OBJECT_centroids = regionprops(binaryImage1, 'Centroid','BoundingBox'); % Get animal centroids

%% Plot fly detection results

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(1,2,1)
imagesc(ImDiff);
axis equal;
xlim([0 image_width])
ylim([0 image_height])
title('Bottom-hat filtered for enhancing blob contrast')
% insert scale bar
hold on
plot([0;ROI_diameter_pix_mean], [image_height-2;image_height-2], 'w', 'LineWidth', 4)
hold off
text(ROI_diameter_pix_mean/2,image_height-30, [num2str(ROI_diameter_mm),' mm'], 'HorizontalAlignment','center','FontSize',5,'Color','w')
subplot(1,2,2)
imagesc(binaryImage1);
axis equal;
xlim([0 image_width])
ylim([0 image_height])
title(['Thresholded ','> ',num2str(OBJECT_threshold),' (',num2str(length(OBJECT_centroids)),' objects detected)'])
% insert scale bar
hold on
plot([0;ROI_diameter_pix_mean], [image_height-2;image_height-2], 'w', 'LineWidth', 4)
hold off
text(ROI_diameter_pix_mean/2,image_height-30, [num2str(ROI_diameter_mm),' mm'], 'HorizontalAlignment','center','FontSize',5,'Color','w')
for n=1:size(OBJECT_centroids,1)
     rectangle('Position',OBJECT_centroids(n).BoundingBox,'EdgeColor','g','LineWidth',2)
    centroids = cat(1,OBJECT_centroids.Centroid);
end
for i=1:ROI_sum
line(ROI_boundaries_new_ordered{i,1}(:,2),ROI_boundaries_new_ordered{i,1}(:,1),'LineWidth',1,'Color','w')  
end


 for i=1:ROI_sum
shiftX{i}=MinYX_new{i}(1,end);
shiftY{i}=MinYX_new{i}(1,1);
 end


 
%% Preallocate variables for speed
fprintf('Preallocating variables for speed \n')
for i=1:ROI_sum % numROIs
Outputfilename{i} = append(videoname,'_fly_',num2str(i));
xCentroids{i} = [NaN];
yCentroids{i} = [NaN];
h1{i} = [NaN];
Xall{i} = zeros(v.NumFrames,1);
Yall{i} = zeros(v.NumFrames,1);
reprojXall{i} = NaN(v.NumFrames,1);
reprojYall{i} = NaN(v.NumFrames,1);
allCentroids{i}=[NaN,NaN];
xCentroids_old{i}=NaN;
yCentroids_old{i}=NaN;
framesflylost{i}=0;
framesflymorethanone{i}=0;
flylost{i}=0
IdxMineucl{i}=0
props{i} = zeros(v.NumFrames,1);
reprojX{i} = zeros(v.NumFrames,1);
reprojY{i} = zeros(v.NumFrames,1);
maybepoint{i} = [NaN,NaN];
eucl{i} = [NaN,NaN];
CurrentPoint{i} = [NaN,NaN];
Mineucl{i} = [NaN,NaN];
closestpoint{i} = [NaN,NaN];
end


%% Prepare real-time figure
f= figure
axis equal
ax = gca();
set(gca, 'xlimmode','manual',...
'ylimmode','manual',...
'zlimmode','manual',...
'climmode','manual',...
'alimmode','manual');
 ylim([0 image_height]) 
 xlim([0 image_width]) 
h2 = imagesc('CData',binaryImage1);
colormap([1 1 1; 0 0.4470 0.7410]);
set(gca, 'YDir','reverse')
set(gca,'NextPlot','replace')
for i=1:ROI_sum
line(ROI_boundaries_new_ordered{i,1}(:,2),ROI_boundaries_new_ordered{i,1}(:,1),'HandleVisibility','off','Color',[0 0 0])  
end
for i=1:ROI_sum
text(yx_centroid_list_new(i,2),yx_centroid_list_new(i,1),num2str(i), 'HorizontalAlignment','center','HandleVisibility','off','Color',[0.5 0.5 0.5])
end
for i=1:ROI_sum
h1{i} = animatedline(ax,'color',[0.5 0.5 0.5],'Parent',ax,'HandleVisibility','off','MaximumNumPoints',300); % after yyaxis left; set to axis color.
ax = gca();
end
drawnow


%% Start Tracking

t0 = clock;
for j = 1:v.NumFrames % Start tracking

    tic;
   
frame = read(v,j); % Read frame
frame = rgb2gray(frame);
[warpedImage,newOrigin] = undistortImage(frame,cameraParams); % Undistort image
ImDiff = imabsdiff(warpedImage,MaxProj); % Subtract background (MAX intensity projection)
ImDiff(~BW) = 0;
binaryImage = bwareafilt(ImDiff > OBJECT_threshold,[10 3000]); % threshold image and filter objects by size
props = regionprops(binaryImage, 'Centroid'); % get object coordinates
props = cat(1,props.Centroid);

for i = 1:ROI_sum
 
% Sort points to ROIs    
CurrentPoint{i}=props(props(:,1)>= MinYX_new{i}(1,2) & props(:,1)<= MaxYX_new{i}(1,2) & props(:,2)>= MinYX_new{i}(1,1) & props(:,2)<= MaxYX_new{i}(1,1),:);

% If more objects, find object closest to previous position
if size(CurrentPoint{1,i},1) > 1 
    framesflymorethanone{i}=framesflymorethanone{i}+1;
    for k=1:size(CurrentPoint{1,i},1)
        maybepoint{1,i}(k,:)=CurrentPoint{1,i}(k,:);        
        eucl{1,i}(k,:) = norm([xCentroids_old{i} yCentroids_old{i}] - maybepoint{1,i}(k,:));     
    end
[Mineucl{i},IdxMineucl{i}] =min(eucl{1,i});
closestpoint{i}=maybepoint{1,i}(IdxMineucl{i},:);
xCentroids{i} = closestpoint{i}(1,1);
yCentroids{i} = closestpoint{i}(1,2);
eucl{1,i}=[];
maybepoint{1,i}=[];
else

% If object is lost, assume last position until it appears again    
flylost{i} = isempty(CurrentPoint{1,i});
if flylost{i} > 0
    framesflylost{i}=framesflylost{i}+1;
    xCentroids{i} = xCentroids_old{i} ;
    yCentroids{i} = yCentroids_old{i};   
else
    xCentroids{i} = CurrentPoint{1,i}(1,1);
    yCentroids{i} = CurrentPoint{1,i}(1,2); 
end
end
Xall{i}(j) = xCentroids{i};
Yall{i}(j) = yCentroids{i};

xCentroids_old{i} = xCentroids{i} ;
yCentroids_old{i} = yCentroids{i};  

  addpoints(h1{i},xCentroids{i},yCentroids{i}); % Add points to plot
end
 
   h2.CData=binaryImage; % Plot thresholded image
  drawnow limitrate nocallbacks; % Update plot
  
 frameNr(j) = j; % Display frame number
 fps=1/elapsedTime % Display elapsed time
 elapsedTimetotal=etime(clock, t0)
 elapsedTime = toc;

end


for m=1:ROI_sum
    FinalCoordinates{m}=horzcat(Xall{1,m},Yall{1,m});
    first_nonNaN_idx{m} = find(~isnan(FinalCoordinates{m}), 1);
    FinalCoordinates{m}(1:first_nonNaN_idx{m},1)=FinalCoordinates{m}(first_nonNaN_idx{m},1);
    FinalCoordinates{m}(1:first_nonNaN_idx{m},2)=FinalCoordinates{m}(first_nonNaN_idx{m},2);
end


%% Save data
save(append(videoname,'\',videoname));



%% Data preparation for analysis

timesum_s=timeall;
timesum_ms=timesum_s*1000;
timesum_ms = fix(timesum_ms);

% plot and save overview
figure
hold on
axis equal
ylim([0 image_height]) 
xlim([0 image_width])
ax = gca(); 
set(gca, 'YDir','reverse')
for i=1:ROI_sum
line(ROI_boundaries_new_ordered{i,1}(:,2),ROI_boundaries_new_ordered{i,1}(:,1),'HandleVisibility','off')  
end
for i=1:ROI_sum
text(yx_centroid_list_new(i,2),yx_centroid_list_new(i,1),num2str(i), 'HorizontalAlignment','center','HandleVisibility','off','FontSize',3)
end
for i=1:ROI_sum
line(FinalCoordinates{1,i}(:,1),FinalCoordinates{1,i}(:,2),'HandleVisibility','off')  
end
exportgraphics(gcf,append(videoname,'\',videoname,'_overview.jpg'),'Resolution',1000);



for m=1:ROI_sum
    FinalCoordinates{m}=horzcat(Xall{1,m},Yall{1,m});
    first_nonNaN_idx{m} = find(~isnan(FinalCoordinates{m}), 1);
    FinalCoordinates{m}(1:first_nonNaN_idx{m},1)=FinalCoordinates{m}(first_nonNaN_idx{m},1);
    FinalCoordinates{m}(1:first_nonNaN_idx{m},2)=FinalCoordinates{m}(first_nonNaN_idx{m},2);
end


% Rotate every second ROI counter-clockwise by rotationtheta 
% If no rotation is wanted, set rotationtheta to 0
for i=2:2:ROI_sum
CenterYX{i}=MinYX_new{i}+(0.5*(MaxYX_new{i}-MinYX_new{i}));
x_cent = CenterYX{1,i}(1,2);
y_cent = CenterYX{1,i}(1,1);
rotationcent = repmat([x_cent;y_cent], 1, length(FinalCoordinates{1,i}));
rotationcent=rotationcent';
rotationCalc = [cos(rotationtheta) -sin(rotationtheta); sin(rotationtheta) cos(rotationtheta)];
rotations = FinalCoordinates{1,i} - rotationcent;     
rotations=rotations';
rotations1 = rotationCalc*rotations;          
rotationFinal{i} = rotations1 + rotationcent';   
FinalCoordinates{1,i}=rotationFinal{i}';
end
FinalCoordinates2Rotated=FinalCoordinates;


% Pixel size in mm
Pixeltomm=ROI_diameter_mm/(ROI_diameter_pix_mean);

% convert to mm 
for k=1:ROI_sum
    FinalCoordinates2RotatedMM{k}=FinalCoordinates2Rotated{k}*Pixeltomm;
end

% Linear extrapolation of XY cooordinates to downsampledframeratehz
timedownsampled = 0:1/downsampledframeratehz:v.Duration-1/downsampledframeratehz;
for k=1:ROI_sum
FinalCoordinates2RotatedMMDownsampled{k} = interp1(timesum_s,FinalCoordinates2RotatedMM{k},timedownsampled,'linear','extrap');
end

Numberframes=numel(FinalCoordinates2RotatedMMDownsampled{1,1}(:,1));

% Loop through ROIs
for k=1:ROI_sum

   if isnan(sum(FinalCoordinates2RotatedMMDownsampled{k}))
       fprintf('Not saving ROI \n')
   else
 
RoiNr{k}= k; 
eucldist{k}=sqrt( sum( abs( diff( FinalCoordinates2RotatedMMDownsampled{1,k} ) ).^2, 2 ) );
eucldist{k}(eucldist{k}==0)=NaN;

% Set XY only if eucldist was above walkingthreshold
for i=2:Numberframes-1
    walkingthresholdtest=eucldist{k}>=walkingthreshold;
if walkingthresholdtest(i-1)<1
    FinalCoordinates2RotatedMMDownsampled{1,k}(i,:)=FinalCoordinates2RotatedMMDownsampled{1,k}(i-1,:);
    eucldist{k}(i-1,:)=sqrt( sum( abs(FinalCoordinates2RotatedMMDownsampled{1,k}(i,:)-FinalCoordinates2RotatedMMDownsampled{1,k}(i-1,:)).^2, 2 ) );
    eucldist{k}(i,:)=sqrt( sum( abs(FinalCoordinates2RotatedMMDownsampled{1,k}(i,:)-FinalCoordinates2RotatedMMDownsampled{1,k}(i+1,:)).^2, 2 ) );
    
else    
end
end

% calculate center of cropped ROI in mm
CenterYXmm{k}=MinYX_new{k}+(0.5*(MaxYX_new{k}-MinYX_new{k}));
CenterYXmm{k}=CenterYXmm{k}*Pixeltomm;
% shift center to 0.0
FinalCoordinates2RotatedMMDownsampledZERO{k}=FinalCoordinates2RotatedMMDownsampled{k};
FinalCoordinates2RotatedMMDownsampledZERO{k}(:,1)=FinalCoordinates2RotatedMMDownsampledZERO{k}(:,1)-CenterYXmm{k}(1,2);
FinalCoordinates2RotatedMMDownsampledZERO{k}(:,2)=FinalCoordinates2RotatedMMDownsampledZERO{k}(:,2)-CenterYXmm{k}(1,1);

% Flip axes. This converts coordinates as seen from the animals's perspective instead of 'from below'.
% Flip around x-axis
FinalCoordinates2RotatedMMDownsampledZERO{k}(:,2) = FinalCoordinates2RotatedMMDownsampledZERO{k}(:,2)*(-1);
% Flip around y-axis
FinalCoordinates2RotatedMMDownsampledZERO{k}(:,1) = FinalCoordinates2RotatedMMDownsampledZERO{k}(:,1)*(-1);

% shift ROI center to 0.0
ROI_boundaries_new_ordered{k}=ROI_boundaries_new_ordered{k}*Pixeltomm
ROI_boundaries_new_ordered{k}(:,1)=ROI_boundaries_new_ordered{k}(:,1)-CenterYXmm{k}(1,1);
ROI_boundaries_new_ordered{k}(:,2)=ROI_boundaries_new_ordered{k}(:,2)-CenterYXmm{k}(1,2);
% flip ROI around x-axis
ROI_boundaries_new_ordered{k}(:,2) = ROI_boundaries_new_ordered{k}(:,2)*(-1)+max(ROI_boundaries_new_ordered{k}(:,2))+min(ROI_boundaries_new_ordered{k}(:,2));
% flip ROI around x-axis
ROI_boundaries_new_ordered{k}(:,1) = ROI_boundaries_new_ordered{k}(:,1)*(-1)+max(ROI_boundaries_new_ordered{k}(:,1))+min(ROI_boundaries_new_ordered{k}(:,1));











%% Calculate behavioral parameters

% Activity parameters

eucldist{k}=sqrt( sum( abs( diff( FinalCoordinates2RotatedMMDownsampledZERO{1,k} ) ).^2, 2 ) );
eucldistALL{k}=eucldist{k} ;
eucldist{k}(eucldist{k}==0)=NaN;
eucldist{k}(eucldist{k}>=Jumpingthreshold)=NaN;
eucldistSum{k} = nansum(eucldist{k});

framesmoving{k}=numel(eucldist{k}(eucldist{k}>=walkingthreshold));
perctimemoving{k}=(framesmoving{k}/Numberframes*100);
framessitting{k}=numel(eucldist{k}(eucldist{k}<walkingthreshold));
perctimesitting{k}=100-perctimemoving{k};
numberpausesTT{k}=eucldistALL{k}<=walkingthreshold==1;
idx{k} = diff(numberpausesTT{k}.')==1;
catnum{k}=1+cumsum([0 idx{k}].');
count{k} = accumarray(catnum{k},numberpausesTT{k});
numberpausesTT{k}=sum(count{k}>=10);
medianpausedurationsecTT{k}=nanmedian(count{k}((count{k}>=10)))/downsampledframeratehz;
totalpausedurationsecTT{k}=sum(count{k}((count{k}>=10)))/downsampledframeratehz;
meanspeedALL{k} = (eucldistSum{k}/numel(eucldist{k}))*downsampledframeratehz;
meanspeedMOV{k} = (eucldistSum{k}/framesmoving{k})*downsampledframeratehz;
NumJumps{k}=sum(eucldist{k} > Jumpingthreshold);

Centerpoint= [0 0];
for i=1:Numberframes
distancetoCenter{k}(i) = norm(Centerpoint - ( FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,:)));
end

radiusmm{k}= (ROI_diameter_pix{k}/2)*Pixeltomm;
innerouterborder{k}=radiusmm{k}-radiusmm{k}/5; % calculate inner border
framesinner{k}=numel(distancetoCenter{k}(distancetoCenter{k}<innerouterborder{k}));
framesouter{k}=numel(distancetoCenter{k}(distancetoCenter{k}>=innerouterborder{k}));
perctimeinner{k}=framesinner{k}/Numberframes*100;
perctimeuoter{k}=100-perctimeinner{k};

% Angle all frames
for i=2:Numberframes
    absoluteAngleALL{k}(i,1)=rad2deg(atan2(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,2) - FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i-1,2) ,(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,1)  - FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i-1,1) )));
    absoluteAngleALL{k}(absoluteAngleALL{k}==0)=NaN;
    if isnan(absoluteAngleALL{k}(i,1))
        absoluteAngleALL{k}(i,1)=absoluteAngleALL{k}(i-1,1);          
    end
end
first_nonNaN_idx_angle{k} = find(~isnan(absoluteAngleALL{k}), 1);
absoluteAngleALL{k}(1:first_nonNaN_idx_angle{k},1)=absoluteAngleALL{k}(first_nonNaN_idx_angle{k},1);
% Angle only moving -180,+180
for i=2:Numberframes
absoluteAngleMOV{k}(i,1)=rad2deg(atan2(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,2) - FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i-1,2) ,(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,1)  - FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i-1,1) )));
 absoluteAngleMOV{k}(absoluteAngleMOV{k}==0)=NaN;
 absoluteAngleMOV{k}(eucldistALL{k}>2)=NaN;
end
% Angle not moving
for i=1:Numberframes-1
    if isnan(eucldist{k}(i,1))
            absoluteAngleSTOP{k}(i,1)=absoluteAngleALL{k}(i,1);          
    else
            absoluteAngleSTOP{k}(i,1)=NaN;
    end
end
% Angle all without edges 
absoluteAngleALLcenter{k}=absoluteAngleALL{k}(distancetoCenter{k}(1:length(absoluteAngleALL{k}))<innerouterborder{k});
% Angle MOV without edges
absoluteAngleMOVcenter{k}=absoluteAngleMOV{k}(distancetoCenter{k}(1:length(absoluteAngleMOV{k}))<innerouterborder{k});
% Angle MOV only edges 
absoluteAngleMOVouter{k}=absoluteAngleMOV{k}(distancetoCenter{k}(1:length(absoluteAngleMOV{k}))>=innerouterborder{k});
% Angle STOP without edges
absoluteAngleSTOPcenter{k}=absoluteAngleSTOP{k}(distancetoCenter{k}(1:length(absoluteAngleSTOP{k}))<innerouterborder{k});
% Angle all frames axial 0,+180
absoluteAngleALLaxial{k} = absoluteAngleALL{k};
absoluteAngleALLaxialLOG{k} = absoluteAngleALL{k} < 0;
absoluteAngleALLaxial{k}(absoluteAngleALLaxialLOG{k}) = absoluteAngleALLaxial{k}(absoluteAngleALLaxialLOG{k}) + 180;
% Angle only moving axial 0,+180
absoluteAngleMOVaxial{k} = absoluteAngleMOV{k};
absoluteAngleMOVaxialLOG{k} = absoluteAngleMOV{k} < 0;
absoluteAngleMOVaxial{k}(absoluteAngleMOVaxialLOG{k}) = absoluteAngleMOVaxial{k}(absoluteAngleMOVaxialLOG{k}) + 180;
% Angle not moving axial 0,+180
absoluteAngleSTOPaxial{k} = absoluteAngleSTOP{k};
absoluteAngleSTOPaxialLOG{k} = absoluteAngleSTOP{k} < 0;
absoluteAngleSTOPaxial{k}(absoluteAngleSTOPaxialLOG{k}) = absoluteAngleSTOPaxial{k}(absoluteAngleSTOPaxialLOG{k}) + 180;
% Angle all axial without edges 10%
absoluteAngleALLaxialcenter{k}=absoluteAngleALLaxial{k}(distancetoCenter{k}(1:length(absoluteAngleALLaxial{k}))<innerouterborder{k});
% Angle MOV axial without edges 10%
absoluteAngleMOVaxialcenter{k}=absoluteAngleMOVaxial{k}(distancetoCenter{k}(1:length(absoluteAngleMOVaxial{k}))<innerouterborder{k});
% Angle STOP axial without edges 10%
absoluteAngleSTOPaxialcenter{k}=absoluteAngleSTOPaxial{k}(distancetoCenter{k}(1:length(absoluteAngleSTOPaxial{k}))<innerouterborder{k});

% Angular velocity
TurningAngleMOV{k}=rad2deg(angdiff(deg2rad(absoluteAngleMOV{k}(1:end))));
TurningAngleMOVcenter{k}=rad2deg(angdiff(deg2rad(absoluteAngleMOVcenter{k}(1:end))));
TurningAngleMOVouter{k}=rad2deg(angdiff(deg2rad(absoluteAngleMOVouter{k}(1:end))));

% Mean Angle
absoluteAngleALLnoNAN{1,k}=absoluteAngleALL{1,k}(~isnan(absoluteAngleALL{1,k}));
MeanabsoluteAngleALL{k}=circ_mean((deg2rad(absoluteAngleALLnoNAN{1,k})));
MeanabsoluteAngleALL{k}=rad2deg(MeanabsoluteAngleALL{k});
absoluteAngleMOVnoNAN{1,k}=absoluteAngleMOV{1,k}(~isnan(absoluteAngleMOV{1,k}));
MeanabsoluteAngleMOV{k}=circ_mean((deg2rad(absoluteAngleMOVnoNAN{1,k})));
MeanabsoluteAngleMOV{k}=rad2deg(MeanabsoluteAngleMOV{k});
absoluteAngleSTOPnoNAN{1,k}=absoluteAngleSTOP{1,k}(~isnan(absoluteAngleSTOP{1,k}));
MeanabsoluteAngleSTOP{k}=circ_mean((deg2rad(absoluteAngleSTOPnoNAN{1,k})));
MeanabsoluteAngleSTOP{k}=rad2deg(MeanabsoluteAngleSTOP{k});
% Mean anbgle axial
absoluteAngleALLaxialnoNAN{1,k}=absoluteAngleALLaxial{1,k}(~isnan(absoluteAngleALLaxial{1,k}));
absoluteAngleALLaxialnoNAN{1,k}=absoluteAngleALLaxialnoNAN{1,k}*2;
MeanabsoluteAngleALLaxial{k}=circ_mean((deg2rad(absoluteAngleALLaxialnoNAN{1,k})));
MeanabsoluteAngleALLaxial{k}=rad2deg(MeanabsoluteAngleALLaxial{k}/2);
MeanabsoluteAngleALLaxial{k}(MeanabsoluteAngleALLaxial{k}<0)=MeanabsoluteAngleALLaxial{k}+180;
absoluteAngleMOVaxialnoNAN{1,k}=absoluteAngleMOVaxial{1,k}(~isnan(absoluteAngleMOVaxial{1,k}));
absoluteAngleMOVaxialnoNAN{1,k}=absoluteAngleMOVaxialnoNAN{1,k}*2;
MeanabsoluteAngleMOVaxial{k}=circ_mean((deg2rad(absoluteAngleMOVaxialnoNAN{1,k})));
MeanabsoluteAngleMOVaxial{k}=rad2deg(MeanabsoluteAngleMOVaxial{k}/2);
MeanabsoluteAngleMOVaxial{k}(MeanabsoluteAngleMOVaxial{k}<0)=MeanabsoluteAngleMOVaxial{k}+180;
absoluteAngleSTOPaxialnoNAN{1,k}=absoluteAngleSTOPaxial{1,k}(~isnan(absoluteAngleSTOPaxial{1,k}));
absoluteAngleSTOPaxialnoNAN{1,k}=absoluteAngleSTOPaxialnoNAN{1,k}*2;
MeanabsoluteAngleSTOPaxial{k}=circ_mean((deg2rad(absoluteAngleSTOPaxialnoNAN{1,k})));
MeanabsoluteAngleSTOPaxial{k}=rad2deg(MeanabsoluteAngleSTOPaxial{k}/2);
MeanabsoluteAngleSTOPaxial{k}(MeanabsoluteAngleSTOPaxial{k}<0)=MeanabsoluteAngleSTOPaxial{k}+180;
% Mean Angle no edge
absoluteAngleALLnoNANcenter{1,k}=absoluteAngleALLcenter{1,k}(~isnan(absoluteAngleALLcenter{1,k}));
MeanabsoluteAngleALLcenter{k}=circ_mean((deg2rad(absoluteAngleALLnoNANcenter{1,k})));
MeanabsoluteAngleALLcenter{k}=rad2deg(MeanabsoluteAngleALLcenter{k});
absoluteAngleMOVnoNANcenter{1,k}=absoluteAngleMOVcenter{1,k}(~isnan(absoluteAngleMOVcenter{1,k}));
MeanabsoluteAngleMOVcenter{k}=circ_mean((deg2rad(absoluteAngleMOVnoNANcenter{1,k})));
MeanabsoluteAngleMOVcenter{k}=rad2deg(MeanabsoluteAngleMOVcenter{k});
absoluteAngleSTOPnoNANcenter{1,k}=absoluteAngleSTOPcenter{1,k}(~isnan(absoluteAngleSTOPcenter{1,k}));
MeanabsoluteAngleSTOPcenter{k}=circ_mean((deg2rad(absoluteAngleSTOPnoNANcenter{1,k})));
MeanabsoluteAngleSTOPcenter{k}=rad2deg(MeanabsoluteAngleSTOPcenter{k});
% Mean angle axial no edge 10%
absoluteAngleALLaxialnoNANcenter{1,k}=absoluteAngleALLaxialcenter{1,k}(~isnan(absoluteAngleALLaxialcenter{1,k}));
absoluteAngleALLaxialnoNANcenter{1,k}=absoluteAngleALLaxialnoNANcenter{1,k}*2;
MeanabsoluteAngleALLaxialcenter{k}=circ_mean((deg2rad(absoluteAngleALLaxialnoNANcenter{1,k})));
MeanabsoluteAngleALLaxialcenter{k}=rad2deg(MeanabsoluteAngleALLaxialcenter{k}/2);
MeanabsoluteAngleALLaxialcenter{k}(MeanabsoluteAngleALLaxialcenter{k}<0)=MeanabsoluteAngleALLaxialcenter{k}+180;
absoluteAngleMOVaxialnoNANcenter{1,k}=absoluteAngleMOVaxialcenter{1,k}(~isnan(absoluteAngleMOVaxialcenter{1,k}));
absoluteAngleMOVaxialnoNANcenter{1,k}=absoluteAngleMOVaxialnoNANcenter{1,k}*2;
MeanabsoluteAngleMOVaxialcenter{k}=circ_mean((deg2rad(absoluteAngleMOVaxialnoNANcenter{1,k})));
MeanabsoluteAngleMOVaxialcenter{k}=rad2deg(MeanabsoluteAngleMOVaxialcenter{k}/2);
MeanabsoluteAngleMOVaxialcenter{k}(MeanabsoluteAngleMOVaxialcenter{k}<0)=MeanabsoluteAngleMOVaxialcenter{k}+180;
absoluteAngleSTOPaxialnoNANcenter{1,k}=absoluteAngleSTOPaxialcenter{1,k}(~isnan(absoluteAngleSTOPaxialcenter{1,k}));
absoluteAngleSTOPaxialnoNANcenter{1,k}=absoluteAngleSTOPaxialnoNANcenter{1,k}*2;
MeanabsoluteAngleSTOPaxialcenter{k}=circ_mean((deg2rad(absoluteAngleSTOPaxialnoNANcenter{1,k})));
MeanabsoluteAngleSTOPaxialcenter{k}=rad2deg(MeanabsoluteAngleSTOPaxialcenter{k}/2);
MeanabsoluteAngleSTOPaxialcenter{k}(MeanabsoluteAngleSTOPaxialcenter{k}<0)=MeanabsoluteAngleSTOPaxialcenter{k}+180;


% Median Angular velocity when moving
MedianTurningAngleMOVall{k}=nanmedian(TurningAngleMOV{k});
MedianTurningAngleMOVall{k}=MedianTurningAngleMOVall{k}*downsampledframeratehz;
AbsTurningAngleSum{k}=sum(abs(TurningAngleMOV{k}(~isnan(TurningAngleMOV{k}))));
% Median Angular velocity when moving in center
MedianTurningAngleMOVcenter{k}=nanmedian(TurningAngleMOVcenter{k});
MedianTurningAngleMOVcenter{k}=MedianTurningAngleMOVcenter{k}*downsampledframeratehz;
AbsTurningAngleSumcenter{k}=sum(abs(TurningAngleMOVcenter{k}(~isnan(TurningAngleMOVcenter{k}))));
% Median Angular velocity when moving near the edge
MedianTurningAngleMOVouter{k}=nanmedian(TurningAngleMOVouter{k});
MedianTurningAngleMOVouter{k}=MedianTurningAngleMOVouter{k}*downsampledframeratehz;
AbsTurningAngleSumouter{k}=sum(abs(TurningAngleMOVouter{k}(~isnan(TurningAngleMOVouter{k}))));

% Vector strength
vectorStrengthMOV{k}=circ_r(deg2rad(absoluteAngleMOV{k}));

% Meander
eucldistnozero{k}=eucldist{k};
eucldistnozero{k}(eucldistnozero{k}==0)=NaN;
Meander{k}=TurningAngleMOV{k}./eucldistnozero{k};
MedianMeander{k}=nanmedian(Meander{k});

% Centrophobicity
Centrophob{k}=distancetoCenter{k};
Centrophob{k}(Centrophob{k}<innerouterborder{k})=0;
Centrophob{k}(Centrophob{k}>=innerouterborder{k})=1;
MeanCentrophob{k}=nanmean(Centrophob{k});

% Stripe deviation (for Buridan stimulus)
Stripe1mm=[0 153]; % Stripe coordinates in mm stripe 1
Stripe2mm=[0 -153]; % Stripe coordinates in mm stripe 2
for i=1:length(FinalCoordinates2RotatedMMDownsampledZERO{1,1})
StripeDeviationAngleStripe1{k,1}(i,1)=rad2deg(atan2(Stripe1mm(1,2)-FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,2),Stripe1mm(1,1)-FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,1)));   
StripeDeviationAngleStripe2{k,1}(i,1)=rad2deg(atan2(Stripe2mm(1,2)-FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,2),Stripe2mm(1,1)-FinalCoordinates2RotatedMMDownsampledZERO{1,k}(i,1)));   
StripeDeviation1{k,1}(i,1)=rad2deg(angdiff(deg2rad(absoluteAngleALL{1,k}(i,1)),deg2rad(StripeDeviationAngleStripe1{k,1}(i,1))));
StripeDeviation2{k,1}(i,1)=rad2deg(angdiff(deg2rad(absoluteAngleALL{1,k}(i,1)),deg2rad(StripeDeviationAngleStripe2{k,1}(i,1))));
StripeDeviationFinal{k,1}(i,1)=min(abs(StripeDeviation1{k,1}(i,1)),abs(StripeDeviation2{k,1}(i,1)));
end
StripeDeviationFinal{k,1}(eucldistALL{1,k}==0)=NaN;
StripeDeviationFinal{k,1}(Centrophob{1,k}==1)=NaN;
StripeDeviationFinalMedian{k,1}=nanmedian(StripeDeviationFinal{k,1});

% Y-maze Turns and Turn Bias (if arena size is changed, please change Arm parameters in mm accordingly)
ArmLeft{k}=FinalCoordinates2RotatedMMDownsampledZERO{1,k}(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,1)>4 & FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2)>-3.5,:);
ArmRight{k}=FinalCoordinates2RotatedMMDownsampledZERO{1,k}(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,1)<-4 & FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2)>-3.5,:);
ArmBottom{k}=FinalCoordinates2RotatedMMDownsampledZERO{1,k}(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2)<-3.5,:);

ArmsAllLeft{k}=FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,1)>4 & FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2)>-3.5;
ArmsAllRight{k}=FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,1)<-4 & FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2)>-3.5;
ArmsAllBottom{k}=FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2)<-3.5,;
ArmsAllRight{k}=ArmsAllRight{k}*2;
ArmsAllLeft{k}=ArmsAllLeft{k}*10;
ArmsAllBottom{k}=ArmsAllBottom{k}*4;
ArmsAll{k}=ArmsAllRight{k}+ArmsAllLeft{k}+ArmsAllBottom{k};
ArmsAllNOZERO{k}=ArmsAll{k}(ArmsAll{k}>0);
TurnsDiff{k}=diff(ArmsAllNOZERO{k});
TurnsNumber{k}=length(TurnsDiff{k}(TurnsDiff{k}~=0));
TurnsCW{k}=TurnsDiff{k}(TurnsDiff{k}==-2  | TurnsDiff{k}==-6 | TurnsDiff{k}==8);
TurnsCCW{k}=TurnsDiff{k}(TurnsDiff{k}==2  | TurnsDiff{k}==6 | TurnsDiff{k}==-8);
% Ration CW CCW between 0 and 1
TurnsBias{k}=length(TurnsCW{k})/TurnsNumber{k};

% Plot coordinates within Y-maze arms in different colors to ensure correct arm definitions (optional)
figure;
scatter(ArmLeft{k}(:,1),ArmLeft{k}(:,2));
hold on
scatter(ArmRight{k}(:,1),ArmRight{k}(:,2));
scatter(ArmBottom{k}(:,1),ArmBottom{k}(:,2));
axis equal
exportgraphics(gcf,append(videoname,'\',append(Outputfilename{k},'_ARMS'),'.png'),'Resolution',1000);
close(gcf);



%% Prepare computed variables for saving

    RoiNrSave{k}=append(num2str(k),'_');
    SAVE_ROI_Nr{k} = NaN(size(timedownsampled',1),1);
    SAVE_ROI_Nr{k}(1)=k;
    SAVE_ROI_diameter_mm{k} = NaN(size(timedownsampled',1),1);
    SAVE_ROI_diameter_mm{k}(1)=ROI_diameter_mm; 
    SAVE_RecDursec{k} = NaN(size(timedownsampled',1),1);
    SAVE_RecDursec{k}(1)=v.Duration;
    SAVE_downsampledframeratehz{k} = NaN(size(timedownsampled',1),1);
    SAVE_downsampledframeratehz{k}(1)=downsampledframeratehz;
    SAVE_eucldistSum{k} = NaN(size(timedownsampled',1),1);
    SAVE_eucldistSum{k}(1)=eucldistSum{k};
    SAVE_percflylost{k} = NaN(size(timedownsampled',1),1);
    SAVE_percflylost{1,k}(1,1)=framesflylost{k}/j*100;
    SAVE_percflymorethanone{k} = NaN(size(timedownsampled',1),1);
    SAVE_percflymorethanone{1,k}(1,1)=framesflymorethanone{k}/j*100;
    SAVE_perctimemoving{k} = NaN(size(timedownsampled',1),1);
    SAVE_perctimemoving{1,k}(1,1)=perctimemoving{k};
    SAVE_perctimesitting{k} = NaN(size(timedownsampled',1),1);
    SAVE_perctimesitting{k}(1)=perctimesitting{k};
    SAVE_numberpausesTT{k} = NaN(size(timedownsampled',1),1);
    SAVE_numberpausesTT{k}(1)=numberpausesTT{k};
    SAVE_medianpausedurationsecTT{k} = NaN(size(timedownsampled',1),1);
    SAVE_medianpausedurationsecTT{k}(1)=medianpausedurationsecTT{k};
    SAVE_totalpausedurationsecTT{k} = NaN(size(timedownsampled',1),1);
    SAVE_totalpausedurationsecTT{k}(1)=totalpausedurationsecTT{k};
    SAVE_meanspeedALL{k} = NaN(size(timedownsampled',1),1);
    SAVE_meanspeedALL{k}(1)=meanspeedALL{k};
    SAVE_meanspeedMOV{k} = NaN(size(timedownsampled',1),1);
    SAVE_meanspeedMOV{k}(1)=meanspeedMOV{k};
    SAVE_NumJumps{k} = NaN(size(timedownsampled',1),1);
    SAVE_NumJumps{k}(1)=NumJumps{k};
    if isempty(MeanabsoluteAngleMOV{k})==1;
        MeanabsoluteAngleMOV{k}=NaN; end
    if isempty(MeanabsoluteAngleSTOP{k})==1;
        MeanabsoluteAngleSTOP{k}=NaN; end
    if isempty(MeanabsoluteAngleALL{k})==1;
        MeanabsoluteAngleALL{k}=NaN; end
    if isempty(MeanabsoluteAngleALLaxial{k})==1;
        MeanabsoluteAngleALLaxial{k}=NaN; end
    if isempty(MeanabsoluteAngleMOVaxial{k})==1;
        MeanabsoluteAngleMOVaxial{k}=NaN; end
    if isempty(MeanabsoluteAngleSTOPaxial{k})==1;
        MeanabsoluteAngleSTOPaxial{k}=NaN; end
    SAVE_MeanabsoluteAngleMOV{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleMOV{k}(1)=MeanabsoluteAngleMOV{k};
    SAVE_MeanabsoluteAngleSTOP{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleSTOP{k}(1)=MeanabsoluteAngleSTOP{k};
    SAVE_MeanabsoluteAngleALL{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleALL{k}(1)=MeanabsoluteAngleALL{k};
    SAVE_MeanabsoluteAngleALLaxial{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleALLaxial{k}(1)=MeanabsoluteAngleALLaxial{k};
    SAVE_MeanabsoluteAngleMOVaxial{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleMOVaxial{k}(1)=MeanabsoluteAngleMOVaxial{k};
    SAVE_MeanabsoluteAngleSTOPaxial{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleSTOPaxial{k}(1)=MeanabsoluteAngleSTOPaxial{k};
    if isempty(MeanabsoluteAngleMOVcenter{k})==1;
        MeanabsoluteAngleMOVcenter{k}=NaN; end
    if isempty(MeanabsoluteAngleSTOPcenter{k})==1;
        MeanabsoluteAngleSTOPcenter{k}=NaN; end
    if isempty(MeanabsoluteAngleALLcenter{k})==1;
        MeanabsoluteAngleALLcenter{k}=NaN; end
    if isempty(MeanabsoluteAngleALLaxialcenter{k})==1;
        MeanabsoluteAngleALLaxialcenter{k}=NaN; end
    if isempty(MeanabsoluteAngleMOVaxialcenter{k})==1;
        MeanabsoluteAngleMOVaxialcenter{k}=NaN; end
    if isempty(MeanabsoluteAngleSTOPaxialcenter{k})==1;
        MeanabsoluteAngleSTOPaxialcenter{k}=NaN; end
    SAVE_MeanabsoluteAngleMOVcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleMOVcenter{k}(1)=MeanabsoluteAngleMOVcenter{k};
    SAVE_MeanabsoluteAngleSTOPcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleSTOPcenter{k}(1)=MeanabsoluteAngleSTOPcenter{k};
    SAVE_MeanabsoluteAngleALLcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleALLcenter{k}(1)=MeanabsoluteAngleALLcenter{k};
    SAVE_MednabsoluteAngleALLaxialcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MednabsoluteAngleALLaxialcenter{k}(1)=MeanabsoluteAngleALLaxialcenter{k};
    SAVE_MeanabsoluteAngleMOVaxialcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleMOVaxialcenter{k}(1)=MeanabsoluteAngleMOVaxialcenter{k};
    SAVE_MeanabsoluteAngleSTOPaxialcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanabsoluteAngleSTOPaxialcenter{k}(1)=MeanabsoluteAngleSTOPaxialcenter{k};
    SAVE_MedianTurningAngleMOVall{k} = NaN(size(timedownsampled',1),1);
    SAVE_MedianTurningAngleMOVall{k}(1)=MedianTurningAngleMOVall{k};
    SAVE_MedianTurningAngleMOVcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MedianTurningAngleMOVcenter{k}(1)=MedianTurningAngleMOVcenter{k};    
    SAVE_MedianTurningAngleMOVouter{k} = NaN(size(timedownsampled',1),1);
    SAVE_MedianTurningAngleMOVouter{k}(1)=MedianTurningAngleMOVouter{k};
    if isempty(absoluteAngleMOVnoNANcenter{k})==1;
        absoluteAngleMOVnoNANcenter{k}=NaN; end
    if isempty(absoluteAngleMOVaxialnoNANcenter{k})==1;
        absoluteAngleMOVaxialnoNANcenter{k}=NaN; end
    SAVE_STDabsoluteAngleMOVcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_STDabsoluteAngleMOVcenter{k}(1)=rad2deg(circ_std(deg2rad(absoluteAngleMOVnoNANcenter{1,k})));
    SAVE_STDabsoluteAngleMOVaxialcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_STDabsoluteAngleMOVaxialcenter{k}(1)=rad2deg(circ_std(deg2rad(absoluteAngleMOVaxialnoNANcenter{1,k})));  
    SAVE_VectorstrengthabsoluteAngleMOV{k} = NaN(size(timedownsampled',1),1);
    SAVE_VectorstrengthabsoluteAngleMOV{k}(1)=circ_r(deg2rad(absoluteAngleMOVnoNANcenter{1,k}));
    SAVE_VectorstrengthabsoluteAngleMOVaxial{k} = NaN(size(timedownsampled',1),1);
    SAVE_VectorstrengthabsoluteAngleMOVaxial{k}(1)=circ_r(deg2rad(absoluteAngleMOVaxialnoNANcenter{1,k}));
    SAVE_perctimeinner{k} = NaN(size(timedownsampled',1),1);
    SAVE_perctimeinner{k}(1)=perctimeinner{k};
    SAVE_perctimeuoter{k} = NaN(size(timedownsampled',1),1);
    SAVE_perctimeuoter{k}(1)=perctimeuoter{k};    
    SAVE_MeanCentrophob{k} = NaN(size(timedownsampled',1),1);
    SAVE_MeanCentrophob{k}(1)=MeanCentrophob{k};
    SAVE_eucldist{k} = NaN(size(timedownsampled',1),1);
    SAVE_eucldist{k}(1:size(eucldist{k},1))=eucldist{k};
    SAVE_distancetoCenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_distancetoCenter{k}(1:size(distancetoCenter{k}',1))=distancetoCenter{k}';
    SAVE_absoluteAngleALL{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleALL{k}(1:size(absoluteAngleALL{k},1))=absoluteAngleALL{k};
    SAVE_absoluteAngleMOV{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleMOV{k}(1:size(absoluteAngleMOV{k},1))=absoluteAngleMOV{k};
    SAVE_absoluteAngleSTOP{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleSTOP{k}(1:size(absoluteAngleSTOP{k},1))=absoluteAngleSTOP{k};
    SAVE_absoluteAngleMOVaxial{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleMOVaxial{k}(1:size(absoluteAngleMOVaxial{k},1))=absoluteAngleMOVaxial{k};
    SAVE_absoluteAngleALLaxial{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleALLaxial{k}(1:size(absoluteAngleALLaxial{k},1))=absoluteAngleALLaxial{k};
    SAVE_absoluteAngleSTOPaxial{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleSTOPaxial{k}(1:size(absoluteAngleSTOPaxial{k},1))=absoluteAngleSTOPaxial{k};  
    SAVE_absoluteAngleALLcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleALLcenter{k}(1:size(absoluteAngleALLcenter{k},1))=absoluteAngleALLcenter{k};
    SAVE_absoluteAngleMOVcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleMOVcenter{k}(1:size(absoluteAngleMOVcenter{k},1))=absoluteAngleMOVcenter{k};
    SAVE_absoluteAngleSTOPcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleSTOPcenter{k}(1:size(absoluteAngleSTOPcenter{k},1))=absoluteAngleSTOPcenter{k};
    SAVE_absoluteAngleMOVaxialcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleMOVaxialcenter{k}(1:size(absoluteAngleMOVaxialcenter{k},1))=absoluteAngleMOVaxialcenter{k};
    SAVE_absoluteAngleALLaxialcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleALLaxialcenter{k}(1:size(absoluteAngleALLaxialcenter{k},1))=absoluteAngleALLaxialcenter{k};
    SAVE_absoluteAngleSTOPaxialcenter{k} = NaN(size(timedownsampled',1),1);
    SAVE_absoluteAngleSTOPaxialcenter{k}(1:size(absoluteAngleSTOPaxialcenter{k},1))=absoluteAngleSTOPaxialcenter{k};
    SAVE_TurningAngleMOV{k} = NaN(size(timedownsampled',1),1);
    SAVE_TurningAngleMOV{k}(1:size(TurningAngleMOV{k},1))=TurningAngleMOV{k};
    SAVE_StripeDeviationFinalMedian{k} = NaN(size(timedownsampled',1),1);
    SAVE_StripeDeviationFinalMedian{k}(1:size(StripeDeviationFinalMedian{k},1))=StripeDeviationFinalMedian{k};
    
    
%% Save results table as TXT
Finaltable{k}= table(convertCharsToStrings(videoname),SAVE_ROI_Nr{k}(1,1),SAVE_ROI_diameter_mm{k}(1,1),SAVE_RecDursec{k}(1,1),SAVE_downsampledframeratehz{k}(1,1),SAVE_eucldistSum{k}(1,1),SAVE_perctimemoving{k}(1,1),SAVE_perctimesitting{k}(1,1),SAVE_numberpausesTT{k}(1,1),SAVE_medianpausedurationsecTT{k}(1,1),SAVE_totalpausedurationsecTT{k}(1,1),SAVE_meanspeedMOV{k}(1,1),SAVE_NumJumps{k}(1,1),SAVE_MeanabsoluteAngleALLcenter{k}(1,1),SAVE_MeanabsoluteAngleMOVcenter{k}(1,1),SAVE_MednabsoluteAngleALLaxialcenter{k}(1,1),SAVE_MeanabsoluteAngleMOVaxialcenter{k}(1,1),SAVE_STDabsoluteAngleMOVcenter{k}(1,1),SAVE_STDabsoluteAngleMOVaxialcenter{k}(1,1),SAVE_VectorstrengthabsoluteAngleMOV{k}(1,1),SAVE_VectorstrengthabsoluteAngleMOVaxial{k}(1,1),SAVE_MedianTurningAngleMOVall{k}(1,1),SAVE_MedianTurningAngleMOVcenter{k}(1,1),SAVE_MedianTurningAngleMOVouter{k}(1,1),AbsTurningAngleSum{k}(1,1),MedianTurningAngleMOVcenter{k}(1,1),AbsTurningAngleSumcenter{k}(1,1),SAVE_perctimeinner{k}(1,1),SAVE_perctimeuoter{k}(1,1),SAVE_MeanCentrophob{k}(1,1),SAVE_percflymorethanone{k}(1,1),SAVE_percflylost{k}(1,1),SAVE_StripeDeviationFinalMedian{k}(1,1),TurnsNumber{k},TurnsBias{k},'VariableNames', {'Videoname','roiNr','roidiametermm','durations','sampleratehz','eucldistSum','perctimemoving','perctimenotmoving','numberpauses','medianpausedurationsec','totalpausedurationsec','meanspeedMOV','numJumps','medianAngleCenterAllframes','medianAngleCenterMoving','medianAngleCenterAxialAllframes','medianAngleCenterAxialMoving','Stddeviation','Stddeviationaxial','rlength','rlengthax','medianAngvelMOValldegs','medianAngvelMOVcenterdegs','medianAngvelMOVouterdegs','absTurningAngleSum','meanTurningAngleMOVcenter','absTurningAngleSumcenter','perctimeinner','perctimeuoter','centrophobIndex','SAVE_percflymorethanone','SAVE_percflylost','SAVE_StripeDeviationFinalMedian','TurnsNumber','TurnsBias'});
writetable(Finaltable{k}, append(videoname,'\',Outputfilename{k},'.txt'),'Delimiter','tab');
   
  
%% Create figures

figure
% Plot trajectory
subplot('Position',[0.05 0.65 0.3 0.3])
title('Tracked')
axis equal
hold on
x1 = FinalCoordinates2RotatedMMDownsampledZERO{1,k}(1:end-1,1) ; 
y1 = FinalCoordinates2RotatedMMDownsampledZERO{1,k}(1:end-1,2) ; 
c1 = eucldist{k}*downsampledframeratehz ;
Surfx=[x1 x1];           
Surfy=[y1 y1];           
Surfz=zeros(size(Surfx)); 
Surfc =[c1 c1] ;         
Surfaceplot=surf(Surfx,Surfy,Surfz,Surfc,'EdgeColor','interp','FaceColor','none','Marker','none','LineWidth',1) ;
xlim([-radiusmm{k}-2 radiusmm{k}+2])
ylim([-radiusmm{k}-2 radiusmm{k}+2])
ylabel('mm','FontSize',7)
xlabel('mm','FontSize',7)
colormap jet ; % colormap    
shading flat                  
view(2) 
colorbar 
caxis([0 40]) % define color limits
hold off
title('Track','FontSize',8);
set(gca,'Color','k')
annotation('textbox', [0.235, 0.59, 0.1, 0.1], 'String', append("mm/s"),'FontSize',5,'Color','k','BackgroundColor','none','Margin',1,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')

% Plot smoothed heatmap
subplot('Position',[0.35 0.65 0.3 0.3])
AllPoints = linspace(-radiusmm{k}-2, radiusmm{k}+2, 50);
AllCounts = histcounts2(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2),FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,1), AllPoints, AllPoints);
[GaussX, GaussY] = meshgrid(-5:5);
GaussSigma = 2;
Gauss = exp(-GaussX.^2./(2.*GaussSigma.^2)-GaussY.^2./(2.*GaussSigma.^2));
Gauss = Gauss./sum(Gauss(:));
% Scale heatmap to 95percentile
heatmapcolor=conv2(AllCounts, Gauss, 'same');
heatmapcolor= prctile(heatmapcolor,95,'all');
imagesc(AllPoints, AllPoints, conv2(AllCounts, Gauss, 'same'));
axis equal;
xlabel('mm','FontSize',7)
set(gca, 'XLim', AllPoints([1 end]), 'YLim', AllPoints([1 end]), 'YDir', 'normal','ytick',[]);
colormap jet
caxis([0 heatmapcolor]);
colorbar;
title('Heatmap','FontSize',8);

% Angular plots
% Angles ALL center
subplot('Position',[0.64 0.79 0.1 0.1])
if isnan(sum(absoluteAngleALLcenter{k}))
    absoluteAngleALLcenter{k}(1)=0;
end
polarhistogram(deg2rad(absoluteAngleALLcenter{k}),100,'DisplayStyle','stairs','EdgeColor','k');
hold on
polarhistogram(deg2rad(absoluteAngleALLcenter{k}),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
ax = gca;
ax.FontSize = 4;
title('Angles ALL','FontSize',4);
ax.ThetaTick = [0 45 90 135 180 225 270 315 ];
ax.ThetaTickLabel = {' 0','45','90','135','+/-180','-135','-90','-45'};
ax.RTickLabel = [];
ax.RTick = [];
% Angles MOV center
subplot('Position',[0.76 0.79 0.1 0.1])
if isnan(sum(absoluteAngleMOVcenter{k}))
    absoluteAngleMOVcenter{k}(1)=0;
end
polarhistogram(deg2rad(absoluteAngleMOVcenter{k}),100,'DisplayStyle','stairs','EdgeColor','k');
hold on
polarhistogram(deg2rad(absoluteAngleMOVcenter{k}),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
ax = gca;
ax.FontSize = 4;
title('Angles MOV','FontSize',4);
ax.ThetaTick = [0 45 90 135 180 225 270 315 ];
ax.ThetaTickLabel = {' 0','45','90','135','+/-180','-135','-90','-45'};
ax.RTickLabel = [];
ax.RTick = [];
% Angles STOP center
subplot('Position',[0.88 0.79 0.1 0.1])
if isnan(sum(absoluteAngleSTOPcenter{k}))
    absoluteAngleSTOPcenter{k}(1)=0;
end
polarhistogram(deg2rad(absoluteAngleSTOPcenter{k}),100,'DisplayStyle','stairs','EdgeColor','k');
hold on
polarhistogram(deg2rad(absoluteAngleSTOPcenter{k}),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
ax = gca;
ax.FontSize = 4;
title('Angles STOP','FontSize',4);
ax.ThetaTick = [0 45 90 135 180 225 270 315 ];
ax.ThetaTickLabel = {' 0','45','90','135','+/-180','-135','-90','-45'};
ax.RTickLabel = [];
ax.RTick = [];
% Angles axial ALL center
subplot('Position',[0.64 0.61 0.1 0.1])
if isnan(sum(absoluteAngleALLaxialcenter{k}))
    absoluteAngleALLaxialcenter{k}(1)=0;
end
polarhistogram(deg2rad(absoluteAngleALLaxialcenter{k}),100,'DisplayStyle','stairs','EdgeColor','k');
hold on
polarhistogram(deg2rad(absoluteAngleALLaxialcenter{k}),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
polarhistogram(deg2rad(absoluteAngleALLaxialcenter{k}-180),100,'DisplayStyle','stairs','EdgeColor','k');
polarhistogram(deg2rad(absoluteAngleALLaxialcenter{k}-180),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
hold off
ax = gca;
ax.FontSize = 4;
title('Angles ALL Ax','FontSize',4);
ax.ThetaTick = [0 45 90 135 180 225 270 315 ];
ax.ThetaTickLabel = {' 0','45','90','135','180','45','90','135'};
ax.RTickLabel = [];
ax.RTick = [];
% Angles axial MOV center
subplot('Position',[0.76 0.61 0.1 0.1])
if isnan(sum(absoluteAngleMOVaxialcenter{k}))
    absoluteAngleMOVaxialcenter{k}(1)=0;
end
polarhistogram(deg2rad(absoluteAngleMOVaxialcenter{k}),100,'DisplayStyle','stairs','EdgeColor','k');
hold on
polarhistogram(deg2rad(absoluteAngleMOVaxialcenter{k}),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
polarhistogram(deg2rad(absoluteAngleMOVaxialcenter{k}-180),100,'DisplayStyle','stairs','EdgeColor','k');
polarhistogram(deg2rad(absoluteAngleMOVaxialcenter{k}-180),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
hold off
ax = gca;
ax.FontSize = 4;
title('Angles MOV Ax','FontSize',4);
ax.ThetaTick = [0 45 90 135 180 225 270 315 ];
ax.ThetaTickLabel = {' 0','45','90','135','180','45','90','135'};
ax.RTickLabel = [];
ax.RTick = [];
% Angles axial STOP center
subplot('Position',[0.88 0.61 0.1 0.1])
if isnan(sum(absoluteAngleSTOPaxialcenter{k}))
    absoluteAngleSTOPaxialcenter{k}(1)=0;
end
polarhistogram(deg2rad(absoluteAngleSTOPaxialcenter{k}),100,'DisplayStyle','stairs','EdgeColor','k');
hold on
polarhistogram(deg2rad(absoluteAngleSTOPaxialcenter{k}),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
polarhistogram(deg2rad(absoluteAngleSTOPaxialcenter{k}-180),100,'DisplayStyle','stairs','EdgeColor','k');
polarhistogram(deg2rad(absoluteAngleSTOPaxialcenter{k}-180),100,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0);
hold off
ax = gca;
ax.FontSize = 4;
title('Angles STOP Ax','FontSize',4);
ax.ThetaTick = [0 45 90 135 180 225 270 315 ];
ax.ThetaTickLabel = {' 0','45','90','135','180','45','90','135'};
ax.RTickLabel = [];
ax.RTick = [];

% Data over time
% Position
subplot('Position',[0.05 0.46 0.55 0.08])
plot(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,1))
hold on
plot(FinalCoordinates2RotatedMMDownsampledZERO{1,k}(:,2))
xlim([0 length(timedownsampled)])
ylim([-radiusmm{k}-2 radiusmm{k}+2])
set(gca,'linewidth',0.7,'xticklabel',arrayfun(@num2str,get(gca,'xtick')/downsampledframeratehz,'un',0),'Layer', 'top','XTickLabel',[],'fontsize',5);
ylabel('X/Y','FontSize',4)
title('Data over time','FontSize',8)
box off
annotation('textbox', [0.6, 0.45, 0.1, 0.1], 'String', "X",'FontSize',8,'Color',[0, 0.4470, 0.7410],'EdgeColor','none')
annotation('textbox', [0.6, 0.41, 0.1, 0.1], 'String', "Y",'FontSize',8,'Color',[0.8500, 0.3250, 0.0980],'EdgeColor','none')

% Euclidean distance + jumping
subplot('Position',[0.05 0.16 0.55 0.08])
Jumping{k}=eucldistALL{k}>=Jumpingthreshold;
area(Jumping{k}*35,'FaceColor','r','FaceAlpha',1,'EdgeAlpha',1,'LineWidth',1,'EdgeColor',[0.6 0.8 1],'FaceColor','none')
hold on
area(eucldistALL{k}*downsampledframeratehz,'FaceColor',[0, 0, 0],'FaceAlpha',0.5,'EdgeAlpha',0.2,'EdgeColor','none')
hold off
xlim([0 length(timedownsampled)])
ylim([0 35])
set(gca,'linewidth',0.7,'xticklabel',arrayfun(@num2str,get(gca,'xtick')/downsampledframeratehz,'un',0),'Layer', 'top','XTickLabel',[],'fontsize',5);
ylabel('Speed','FontSize',4)
box off
annotation('textbox', [0.61, 0.175, 0.05, 0.02], 'String', "Jumps",'FontSize',3,'Color','k','BackgroundColor',[0.6 0.8 1],'FaceAlpha',0.3,'Margin',1,'HorizontalAlignment','center','VerticalAlignment','middle')
annotation('textbox', [0.61, 0.205, 0.05, 0.02], 'String', "Walking",'FontSize',3,'Color','w','BackgroundColor',[0 0 0],'FaceAlpha',0.5,'Margin',1,'HorizontalAlignment','center','VerticalAlignment','middle')

% Centrophobicity
subplot('Position',[0.05 0.26 0.55 0.08])
area(Centrophob{k}*ROI_diameter_pix{1,k}*Pixeltomm/2,'FaceColor',[0.6 0.8 1],'FaceAlpha',0.3,'EdgeAlpha',0.3)
hold on
set(gca,'linewidth',0.7,'XTickLabel',[],'fontsize',5);
ylabel('Dist to center','FontSize',4);
xlim([0 length(timedownsampled)])
plot(SAVE_distancetoCenter{k},'k')
hold off
box off
annotation('textbox', [0.61, 0.305, 0.05, 0.02], 'String', append("Edge region"),'FontSize',3,'Color','k','BackgroundColor',[0.6 0.8 1],'FaceAlpha',0.3,'Margin',1,'HorizontalAlignment','center','VerticalAlignment','middle')
annotation('textbox', [0.61, 0.275, 0.05, 0.02], 'String', append("Center region"),'FontSize',3,'Color','k','BackgroundColor',[1 1 1],'Margin',1,'HorizontalAlignment','center','VerticalAlignment','middle')

% Angles over time
subplot('Position',[0.05 0.36 0.55 0.08])
% Define x and y 
AgradX = linspace(0, length(SAVE_absoluteAngleALL{1,k}), length(SAVE_absoluteAngleALL{1,k}))';
AgradY = linspace(180, 180, length(SAVE_absoluteAngleALL{1,k}))';
AgradC = SAVE_absoluteAngleALL{1,k};
AgradN = length(AgradX);
AgradVert = [AgradX(:), AgradY(:); AgradX(:) zeros(AgradN,1)];
AgradM = (1:AgradN-1)';
AgradArea = [AgradM, AgradM+1, AgradM+AgradN+1, AgradM+AgradN];
patch('Faces', AgradArea, 'Vertices', AgradVert, 'FaceVertexCData', [AgradC(:); AgradC(:)], 'FaceColor', 'interp','FaceAlpha',0.2, 'EdgeColor', 'none')
hold on
AgradX = linspace(0, length(SAVE_absoluteAngleALL{1,k}), length(SAVE_absoluteAngleALL{1,k}))';
AgradY = linspace(-180, -180, length(SAVE_absoluteAngleALL{1,k}))';
AgradC = SAVE_absoluteAngleALL{1,k};
AgradN = length(AgradX);
AgradVert = [AgradX(:), AgradY(:); AgradX(:) zeros(AgradN,1)];
AgradM = (1:AgradN-1)';
AgradArea = [AgradM, AgradM+1, AgradM+AgradN+1, AgradM+AgradN];
patch('Faces', AgradArea, 'Vertices', AgradVert, 'FaceVertexCData', [AgradC(:); AgradC(:)], 'FaceColor', 'interp','FaceAlpha',0.2, 'EdgeColor', 'none')
colormap(gca,hsv)

Plotanglediff{k}=abs(diff(SAVE_absoluteAngleALL{k}));
Plotangle{k}=SAVE_absoluteAngleALL{k};
Plotangle{k}(Plotanglediff{k}>200)=NaN;
plot(Plotangle{k},'k')
hold off
anglegradientcolorbar = colorbar();
    set(anglegradientcolorbar,'Position',[0.61    0.36    0.0181    0.0794])% To change size
xlim([0 length(timedownsampled)])
ylim([-180 180])
set(gca,'fontsize',5,'linewidth',0.7,'xticklabel',arrayfun(@num2str,get(gca,'xtick')/downsampledframeratehz,'un',0),'Layer', 'top','XTickLabel',[]);
ylabel('AbsAngle','FontSize',4)
box off
annotation('rectangle',[0.61    0.3608    0.0181    0.0794],'FaceColor','w','FaceAlpha',0.8);


% Angular velocity
subplot('Position',[0.05 0.06 0.55 0.08])
SAVE_TurningAngleMOVsmoothedZero{k}=SAVE_TurningAngleMOV{k};
SAVE_TurningAngleMOVsmoothedZero{k}(isnan(SAVE_TurningAngleMOVsmoothedZero{k}))=0;
SAVE_TurningAngleMOVsmoothedZero{k}=smoothdata(SAVE_TurningAngleMOVsmoothedZero{k},'gaussian',5*downsampledframeratehz);
SAVE_TurningAngleMOVsmoothedZero{k}(SAVE_TurningAngleMOVsmoothedZero{k}==0)=NaN;
AgradX = linspace(0, length(SAVE_TurningAngleMOVsmoothedZero{1,k}), length(SAVE_TurningAngleMOVsmoothedZero{1,k}))';
AgradY = linspace(7, 7, length(SAVE_TurningAngleMOVsmoothedZero{1,k}))';
AgradC = SAVE_TurningAngleMOVsmoothedZero{1,k};
AgradN = length(AgradX);
AgradVert = [AgradX(:), AgradY(:); AgradX(:) zeros(AgradN,1)];
AgradM = (1:AgradN-1)';
AgradArea = [AgradM, AgradM+1, AgradM+AgradN+1, AgradM+AgradN];
patch('Faces', AgradArea, 'Vertices', AgradVert, 'FaceVertexCData', [AgradC(:); AgradC(:)], 'FaceColor', 'interp','FaceAlpha',1, 'EdgeColor', 'none')
hold on
AgradX = linspace(0, length(SAVE_TurningAngleMOVsmoothedZero{1,k}), length(SAVE_TurningAngleMOVsmoothedZero{1,k}))';
AgradY = linspace(-7, -7, length(SAVE_TurningAngleMOVsmoothedZero{1,k}))';
AgradC = SAVE_TurningAngleMOVsmoothedZero{1,k};
AgradN = length(AgradX);
AgradVert = [AgradX(:), AgradY(:); AgradX(:) zeros(AgradN,1)];
AgradM = (1:AgradN-1)';
AgradArea = [AgradM, AgradM+1, AgradM+AgradN+1, AgradM+AgradN];
patch('Faces', AgradArea, 'Vertices', AgradVert, 'FaceVertexCData', [AgradC(:); AgradC(:)], 'FaceColor', 'interp','FaceAlpha',1, 'EdgeColor', 'none')
% Color ramp
colorMap = zeros(101, 3);
colorMap(1:50, 1) = linspace(0.8500, 1, 50);
colorMap(1:50, 2) = linspace(0.3250, 1, 50);
colorMap(1:50, 3) = linspace(0.0980, 1, 50);
colorMap(51:101, 1) = linspace(1, 0, 51);
colorMap(51:101, 2) = linspace(1, 0.4470, 51);
colorMap(51:101, 3) = linspace(1, 0.7410, 51);
colormap(gca,colorMap);
caxis([-7 7])
area(SAVE_TurningAngleMOVsmoothedZero{k},'FaceColor','k')
hold off
angularvelcolorbar = colorbar();
set(angularvelcolorbar,'Position',[0.61    0.0518    0.0181    0.0794])% To change size
ylabel('AbsAngle','FontSize',4)
xlim([0 length(timedownsampled)])
ylim([-7.5 7])
set(gca,'fontsize',5,'linewidth',0.7,'xticklabel',arrayfun(@num2str,get(gca,'xtick')/downsampledframeratehz,'un',0),'Layer', 'top');
ylabel('AbsAngle','FontSize',4)
xlabel('time in s','FontSize',5)
box off
annotation('textbox', [0.76, 0.905, 0.1, 0.1], 'String', append("Angular data center"),'FontSize',8,'Color','k','BackgroundColor','none','Margin',1,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none','fontweight', 'bold')

% Textbox
annotation('textbox', [0.68 0.05 0.25 0.5], ...
    'Interpreter', 'none', ...
    'String', append("Filename: ",Outputfilename{k},newline, ...
    "Roi Nr: ",num2str(RoiNr{k}),newline, ...
    "Duration in s: ",num2str(SAVE_RecDursec{k}(1)),newline, ...
    "Downsampled framerate in hz: ",num2str(SAVE_downsampledframeratehz{k}(1)),newline, ...
    "Distance in mm: ",num2str(SAVE_eucldistSum{k}(1)),newline, ...
    "Mean Speed all frames in mm/s: ",num2str(SAVE_meanspeedALL{k}(1)),newline, ...
    "Mean Speed moving only in mm/s: ",num2str(SAVE_meanspeedMOV{k}(1)),newline, ...
    "Median Angle center all frames in °: ",num2str(SAVE_MeanabsoluteAngleALLcenter{k}(1)),newline, ...
    "Median Angle center moving only in °: ",num2str(SAVE_MeanabsoluteAngleMOVcenter{k}(1)),newline, ...
    "Median Angle center axial all frames in °: ",num2str(SAVE_MednabsoluteAngleALLaxialcenter{k}(1)),newline, ...
    "Median Angle center axial moving only in °: ",num2str(SAVE_MeanabsoluteAngleMOVaxialcenter{k}(1)),newline, ...
    "Std deviation mov center in °: ",num2str(SAVE_STDabsoluteAngleMOVcenter{k}(1)),newline, ...
    "Std deviation mov center axial in °: ",num2str(SAVE_STDabsoluteAngleMOVaxialcenter{k}(1)),newline, ...
    "Resultant vector length mov center: ",num2str(SAVE_VectorstrengthabsoluteAngleMOV{k}(1)),newline, ...
    "Resultant vector length mov centeraxial: ",num2str(SAVE_VectorstrengthabsoluteAngleMOVaxial{k}(1)),newline, ...
    "Median Stripe deviation in °: ",num2str(SAVE_StripeDeviationFinalMedian{k}(1)),newline, ...
    "Med TurningVel MoVAll in °/s: ",num2str(SAVE_MedianTurningAngleMOVall{k}(1)),newline, ...
    "Med TurningVel MoVCenter only in °/s: ",num2str(SAVE_MedianTurningAngleMOVcenter{k}(1)),newline, ...
    "Med TurningVel MoVOuter only in °/s: ",num2str(SAVE_MedianTurningAngleMOVouter{k}(1)),newline, ...
    "Abs Turning sum moving only in °: ",num2str(AbsTurningAngleSum{k}(1,1)),newline, ...
    "Abs Turning sum moving center only in °: ",num2str(AbsTurningAngleSumcenter{k}(1,1)),newline, ...
    "Centrophobicity Index: ",num2str(SAVE_MeanCentrophob{k}(1)),newline, ...
    "% of time moved: ",num2str(SAVE_perctimemoving{k}(1)),newline, ...
    "% of time not moving: ",num2str(SAVE_perctimesitting{k}(1)),newline, ...
    "Number of pauses (1s+): ",num2str(SAVE_numberpausesTT{k}(1)),newline, ...
    "Mean pause duration in s: ",num2str(SAVE_medianpausedurationsecTT{k}(1)),newline, ...
    "% of time spent in center region: ",num2str(SAVE_perctimeinner{k}(1)),newline, ...
    "% of time spent in edge region: ",num2str(SAVE_perctimeuoter{k}(1)),newline, ...
    "Number of frames jumping: ",num2str(SAVE_NumJumps{k}(1)),newline, ...
    "% of time fly lost: ",num2str(SAVE_percflylost{k}(1)),newline, ...
    "% of time more than one object: ",num2str(SAVE_percflymorethanone{k}(1)),newline), ...
    'EdgeColor','none', ...
    'FontSize',4)
 
%% Save Figure
exportgraphics(gcf,append(videoname,'\',Outputfilename{k},'.png'),'Resolution',1000);
close(gcf);
   end
end

%% Optional: Save RAW coordinates as DAT and XML for later analysis using the software presented in:
% Colomb J, Reiter L, Blaszkiewicz J, Wessnitzer J, Brembs B. Open source tracking and analysis of adult Drosophila locomotion in Buridan's paradigm with and without visual targets. PLoS One. 2012;7(8):e42247. doi: 10.1371/journal.pone.0042247. Epub 2012 Aug 9. PMID: 22912692; PMCID: PMC3415391.

% Write DAT
extension= '.dat';
for k=1:ROI_sum
     if isnan(sum(FinalCoordinates2RotatedMMDownsampled{k}))
       fprintf('Not saving ROI \n')
   else
    % Flix X and Y for comparison with standard Buridan
    FinalCoordinates2RotatedFlippedXY=FinalCoordinates2Rotated
    % Flip Y: 
    FinalCoordinates2RotatedFlippedXY{k}(:,2) = FinalCoordinates2RotatedFlippedXY{k}(:,2)*(-1)+max(FinalCoordinates2RotatedFlippedXY{k}(:,2))+min(FinalCoordinates2RotatedFlippedXY{k}(:,2));
    % Flip X: 
    FinalCoordinates2RotatedFlippedXY{k}(:,1) = FinalCoordinates2RotatedFlippedXY{k}(:,1)*(-1)+max(FinalCoordinates2RotatedFlippedXY{k}(:,1))+min(FinalCoordinates2RotatedFlippedXY{k}(:,1));
    RoiNrSave{k}=append(num2str(k),'_');
    FinaltableBuridan{k}= table(frameNr,timesum_ms',FinalCoordinates2RotatedFlippedXY{1,k}(:,1),FinalCoordinates2RotatedFlippedXY{1,k}(:,2),burst','VariableNames', {'frame', 'time','x', 'y','burst'});
    writetable(FinaltableBuridan{k},append(videoname,'\',Outputfilename{k},'.dat'),'Delimiter','tab');

% Write XML    
XMLtext = '<?xml version="1.0"?>';
XMLtext = [XMLtext newline '<HEADER>'];
XMLtext = [XMLtext newline '	<FLY>' append(videoname,'_fly_',num2str(k)) '</FLY>']
XMLtext = [XMLtext newline '	<DATAFILE>' Outputfilename{k} '</DATAFILE>']
XMLtext = [XMLtext newline '	<DURATION>' num2str(v.Duration*1000,'%.0f') '</DURATION>']
XMLtext = [XMLtext newline '	<STRIPE_WIDTH>11</STRIPE_WIDTH>']
XMLtext = [XMLtext newline '	<STRIPE_POS>90,-90</STRIPE_POS>']
XMLtext = [XMLtext newline '	<ARENA_DIAMETER_MM>' num2str(ROI_diameter_mm,'%.0f') '</ARENA_DIAMETER_MM>']
XMLtext = [XMLtext newline '	<OUTER_DIAMETER_MM>' num2str(Cylinder_inner_diameter_mm,'%.0f') '</OUTER_DIAMETER_MM>']
XMLtext = [XMLtext newline '	<ARENA_CENTER_X>' num2str(yx_centroid_list_new(k,2),'%.0f') '</ARENA_CENTER_X>']
XMLtext = [XMLtext newline '	<ARENA_CENTER_Y>' num2str(yx_centroid_list_new(k,1),'%.0f') '</ARENA_CENTER_Y>']
XMLtext = [XMLtext newline '	<ARENA_RADIUS>' num2str(ROI_diameter_pix{1,k}) '</ARENA_RADIUS>']
XMLtext = [XMLtext newline '	<TIMESTAMP>1595509945</TIMESTAMP>']
XMLtext = [XMLtext newline '	<RESX>' num2str(image_height,'%.0f') '</RESX>']
XMLtext = [XMLtext newline '	<RESY>' num2str(image_width,'%.0f') '</RESY>']
XMLtext = [XMLtext newline '	<COMMENTS>' Outputfilename{k}]
XMLtext = [XMLtext newline '</COMMENTS>']
XMLtext = [XMLtext newline '</HEADER>']
fid{k} = fopen(append(videoname,'\',Outputfilename{k},'.XML'), 'wt');
fprintf(fid{k}, '%s\n', XMLtext);
fclose(fid{k});
end
end
close all
end % End of main loop
















 
    
    
    
    