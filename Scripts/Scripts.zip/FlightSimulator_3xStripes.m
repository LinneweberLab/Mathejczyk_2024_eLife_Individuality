%% Buridan flight simulator
% This code tracks the heading of a tethered flying fly in response to panoramically presented vertical stripes in real-time. 
% To initiate fight behavior, air puffs can be automatically triggered via an Arduino controlling a membrane pump using a relay. 
% For this, the script establishes a serial connection to a connected Arduino and sends simple on/off switching signals for the relay.
% Before running first, please make sure to:
%  - have the circular statistics toolbox installed
%    (https://www.mathworks.com/matlabcentral/fileexchange/10676-circular-statistics-toolbox-directional-statistics)
%  - set tracking parameters if necessary (reording time, framerate, illumination thresholds) 
%  - set the correct file location of the stimulus images to be displayed

clear
%% create variables
sex='_m_CS_8d_1913';
ID=datestr(now,'mm-dd-yyyy_HH-MM');
ID=append(ID,sex);
Filename1 = append(ID,'_30degcontr50');

v = videoinput('gentl', 1, 'Mono8');
src = getselectedsource(v);
v.FramesPerTrigger = inf;
v.LoggingMode = 'disk&memory';

diskLogger = VideoWriter(Filename1, 'Grayscale AVI');
v.DiskLogger = diskLogger;
diskLogger.FrameRate = 90;
% diskLogger.Quality = 100;
src.AcquisitionFrameRateEnable = 'True';
src.AcquisitionFrameRate = 89.8866708853478;
v.ROIPosition = [324 238 72 72];

src.ExposureAuto = 'Off';
src.AutoExposureControlLoopDamping = 0.203125;
src.ExposureTime = 10995;
src.Gain = 10;
src.Gamma = 0.696533203125;


vlc_path = 'C:\Program Files\VideoLAN\VLC\vlc';

arduino1 = serialport('COM3',9600);
pause(2.5);
write(arduino1,9,"uint8"); %puff off
% write(arduino1,8,"uint8"); %puff on
flush(arduino1);






%% 4 min Buridan 30deg 50% contrast

Filename1 = append(ID,'_30degcontr50');
diskLogger = VideoWriter(Filename1, 'Grayscale AVI');
v.DiskLogger = diskLogger;
diskLogger.FrameRate = 90;

% prepare stimulus figure. Set the correct file location of the stimulus images to be displayed
blackscreen = imread('C:\Users\Behavior_01\Desktop\Stripe Stimuli\black.bmp');
stimulus1 = imread('C:\Users\Behavior_01\Desktop\Stripe Stimuli\30deg\30degstripe 0deg front 50per contrast.bmp');

stimulusfig=figure('MenuBar', 'none', ...
       'ToolBar', 'none')
stimulusplot = imshow(blackscreen);
set(gca,'units','pixels') 
stimulusx = get(gca,'position') 
set(gcf,'units','pixels') 
stimulusy = get(gcf,'position') 
set(gcf,'position',[stimulusy(1) stimulusy(2) stimulusx(3) stimulusx(4)])
set(gca,'units','normalized','position',[0 0 1 1]) 
stimulusy = get(gcf,'position') 
% need to add pixels for perfect position [1921,953,256,128]
set(gcf,'units','pixels','position',[1921,953,256,128]) 



%% define user parameters
Rectimesec=240;
downsampledFramerate=60;
predictedframes=Rectimesec*downsampledFramerate*1.5;
forwardspeed=20; % 3cm/frame @60hz = 180cm/s

%% preallocate variables
elapsedTime=0;
elapsedTimetotal=0;
Xtraj(1)=0;
Ytraj(1)=0;
pufferOn=0;
heading=zeros(predictedframes,1);
frameNr=zeros(predictedframes,1); 
areaQ1=zeros(predictedframes,1);
areaQ2=zeros(predictedframes,1);
areaQ3=zeros(predictedframes,1);
areaQ4=zeros(predictedframes,1);
areaQ1Surr=zeros(predictedframes,1);
areaQ2Surr=zeros(predictedframes,1);
areaQ3Surr=zeros(predictedframes,1);
areaQ4Surr=zeros(predictedframes,1);
Xtraj=zeros(predictedframes,1);
Ytraj=zeros(predictedframes,1);
stops=zeros(predictedframes,1);
timeall=zeros(predictedframes,1);
framepuff=zeros(predictedframes,1);

%% Prepare plot figure
h= figure;
testimage=zeros(72,72);
testimage(1)=-1;
testimage(end)=2;
imageplot=imagesc(testimage);
set(gca,'Units','pixels')
set(gcf,'doublebuffer','off');

set(gca, 'xlimmode','manual',...
           'ylimmode','manual',...
           'zlimmode','manual',...
           'alimmode','manual');
lineplot=line([35 39],[35 39]);
    
%% Start Tracking

set(stimulusplot,'CData',stimulus1);
start(v);
t0 = clock;
j=1;
while elapsedTimetotal<Rectimesec

%% Find fly
j=j+1;
    tic;
frameoriginal = getdata(v,1);
flushdata(v);
frame = imgaussfilt(frameoriginal,1.5);
mask=frame > 100;
mask=bwconvhull(mask);
mask = bwmorph(mask,'shrink',1);
binaryImage=frame < 39;
binaryImage(~mask) = 0;
binaryImage = bwareafilt(binaryImage,1); 

binaryImage=bwmorph(binaryImage,'thicken',3);

frameoriginalthresh = frameoriginal < 78;
frameoriginalthresh(~mask) = 0;
frameoriginalthresh=frameoriginalthresh-binaryImage;
frameoriginalthresh(frameoriginalthresh<0)=0;

props=regionprops(binaryImage,'ConvexHull','Centroid','Perimeter','Orientation','MajorAxisLength');

binaryplot=binaryImage*2;
binaryplot(frameoriginalthresh>0)=-1;

[threshBodyY, thresBodyX] = find(binaryImage == 1);
[threshYSurr, threshXSurr] = find(frameoriginalthresh == 1);

set(imageplot,'CData',binaryplot);
 
if isempty(props)==1
    props = struct('Centroid',[35 35],'ConvexHull',[NaN NaN],'Perimeter',[NaN NaN],'Orientation',[NaN],'MajorAxisLength',[20]);
end
    
%% Center at 0,0
thresBodyX = thresBodyX-props.Centroid(1,1);
threshBodyY = -threshBodyY+props.Centroid(1,2);
threshXSurr = threshXSurr-props.Centroid(1,1);
threshYSurr = -threshYSurr+props.Centroid(1,2);

ang = props.Orientation;  % degrees

%% Align fly body with x-axis
Xshift = 0;
Yshift = 0;
Xrotation =  (thresBodyX-Xshift)*cosd(ang) + (threshBodyY-Yshift)*sind(ang) + Xshift;
Yrotation = -(thresBodyX-Xshift)*sind(ang) + (threshBodyY-Yshift)*cosd(ang) + Yshift;
XrotationSurr =  (threshXSurr-Xshift)*cosd(ang) + (threshYSurr-Yshift)*sind(ang) + Xshift;
YrotationSurr = -(threshXSurr-Xshift)*sind(ang) + (threshYSurr-Yshift)*cosd(ang) + Yshift;

%% Get area per quadrant
Q1=Xrotation(Xrotation>=props.MajorAxisLength/10 & Yrotation>=0);
areaQ1(j)=length(Q1);
Q2=Xrotation(Xrotation<-props.MajorAxisLength/10 & Yrotation>=0);
areaQ2(j)=length(Q2);
Q3=Xrotation(Xrotation<-props.MajorAxisLength/10 & Yrotation<0);
areaQ3(j)=length(Q3);
Q4=Xrotation(Xrotation>=props.MajorAxisLength/10 & Yrotation<0);
areaQ4(j)=length(Q4);

Q1Surr=XrotationSurr(XrotationSurr>=0 & YrotationSurr>=0);
areaQ1Surr(j)=length(Q1Surr);
Q2Surr=XrotationSurr(XrotationSurr<0 & YrotationSurr>=0);
areaQ2Surr(j)=length(Q2Surr);
Q3Surr=XrotationSurr(XrotationSurr<0 & YrotationSurr<0);
areaQ3Surr(j)=length(Q3Surr);
Q4Surr=XrotationSurr(XrotationSurr>=0 & YrotationSurr<0);
areaQ4Surr(j)=length(Q4Surr);

%% Distinguish head from tail
front=(areaQ1(j)+areaQ4(j))-(areaQ2(j)+areaQ3(j));

if front >= 0 
ang=props.Orientation;
else
    if ang <= 0
    ang=props.Orientation+180; 
    else
    ang=props.Orientation-180; 
    end
end


ang(ang<180)=180+ang;
heading(j)=ang;

if j==2
    heading(1)=heading(j);
end

%% Correct implausible heading switches
if abs(rad2deg(angdiff(deg2rad(heading(j)),deg2rad(heading(j-1)))))>150
heading_opposite(1)=heading(j)+180;
heading_opposite(2)=heading(j)-180;
heading(j)=heading_opposite(heading_opposite >= 0 & heading_opposite < 360);
end

%% Detect stop episodes


stops(j)=(max((areaQ2Surr(j)+areaQ3Surr(j)),(areaQ1Surr(j)+areaQ4Surr(j))))>130;

if stops(j)==1
        heading(j)=NaN;
end


% puff if 1 frame stop
if stops(j)==1 && pufferOn==0 
            puffstart= tic; 
            write(arduino1,8,"uint8");
            flush(arduino1);
            pufferOn=1; 
            framepuff(j)=1;
else
        framepuff(j)=0;
end


% Define puff lenth and delete heading for 3s
if pufferOn==1   
    pufftime = toc(puffstart);
    if pufftime>0.1
        write(arduino1,9,"uint8");
        flush(arduino1);
    end
    if pufftime>3
    pufferOn=0;
    end
 heading(j)=NaN;
end

%% Calculate fictive 2D position
if isnan(heading(j))
    Xtraj(j)=Xtraj(j-1);
    Ytraj(j)=Ytraj(j-1);
else
Xtraj(j)=Xtraj(j-1)+(forwardspeed*cos(deg2rad(heading(j))));
Ytraj(j)=Ytraj(j-1)+(forwardspeed*sin(deg2rad(heading(j))));
end

%% Calculate heading line for drawing
x2=props.Centroid(1,1)+(forwardspeed*cos(deg2rad(heading(j))));
y2=props.Centroid(1,2)+(forwardspeed*sin(-deg2rad(heading(j))));
set(lineplot,'XData',[props.Centroid(1,1) x2],'YData',[props.Centroid(1,2) y2])

drawnow limitrate nocallbacks;


timeall(j)= elapsedTime ;  
    frameNr(j) = j;
   fps=1/elapsedTime
 elapsedTimetotal=etime(clock, t0)
 elapsedTime = toc;
% j


end
stop(v)
set(stimulusplot,'CData',blackscreen);
%% Save variables
bur30degcontr50.timeall=timeall(2:j);
bur30degcontr50.heading=heading(2:j);
bur30degcontr50.Xtraj=Xtraj(2:j);
bur30degcontr50.Ytraj=Ytraj(2:j);
bur30degcontr50.stop=stops(2:j);
bur30degcontr50.areaQ1=areaQ1(2:j);
bur30degcontr50.areaQ2=areaQ2(2:j);
bur30degcontr50.areaQ3=areaQ3(2:j);
bur30degcontr50.areaQ4=areaQ4(2:j);
bur30degcontr50.areaQ1Surr=areaQ1Surr(2:j);
bur30degcontr50.areaQ2Surr=areaQ2Surr(2:j);
bur30degcontr50.areaQ3Surr=areaQ3Surr(2:j);
bur30degcontr50.areaQ4Surr=areaQ4Surr(2:j);
bur30degcontr50.framepuff=framepuff(2:j);


clearvars -except v ID bur30degcontr50 Filename1 arduino1 pufferOn stimulusplot blackscreen



%% 4 min Buridan 30deg 100% contrast


Filename2 = append(ID,'_30degcontr100');
diskLogger = VideoWriter(Filename2, 'Grayscale AVI');
v.DiskLogger = diskLogger;
diskLogger.FrameRate = 90;

% prepare stimulus figure
blackscreen = imread('C:\Users\Behavior_01\Desktop\Stripe Stimuli\black.bmp');
stimulus2 = imread('C:\Users\Behavior_01\Desktop\Stripe Stimuli\30deg\30degstripe 0deg front.bmp');

stimulusfig=figure('MenuBar', 'none', ...
       'ToolBar', 'none')
stimulusplot = imshow(blackscreen);
set(gca,'units','pixels') % set the axes units to pixels
stimulusx = get(gca,'position') % get the position of the axes
set(gcf,'units','pixels') % set the figure units to pixels
stimulusy = get(gcf,'position') % get the figure position
set(gcf,'position',[stimulusy(1) stimulusy(2) stimulusx(3) stimulusx(4)])% set the position of the figure to the length and width of the axes
set(gca,'units','normalized','position',[0 0 1 1]) % set the axes units to pixels
stimulusy = get(gcf,'position') % get the figure position
% need to add pixels for perfect position [1921,953,256,128]
set(gcf,'units','pixels','position',[1921,953,256,128]) % set the axes units to pixels



Rectimesec=240;
downsampledFramerate=60;
predictedframes=Rectimesec*downsampledFramerate*1.5;
forwardspeed=20; % 3cm/frame @60hz = 180cm/s


elapsedTime=0;
elapsedTimetotal=0;
Xtraj(1)=0;
Ytraj(1)=0;
pufferOn=0;
heading=zeros(predictedframes,1);
frameNr=zeros(predictedframes,1); 
areaQ1=zeros(predictedframes,1);
areaQ2=zeros(predictedframes,1);
areaQ3=zeros(predictedframes,1);
areaQ4=zeros(predictedframes,1);
areaQ1Surr=zeros(predictedframes,1);
areaQ2Surr=zeros(predictedframes,1);
areaQ3Surr=zeros(predictedframes,1);
areaQ4Surr=zeros(predictedframes,1);
Xtraj=zeros(predictedframes,1);
Ytraj=zeros(predictedframes,1);
stops=zeros(predictedframes,1);
timeall=zeros(predictedframes,1);
framepuff=zeros(predictedframes,1);

%% Prepare plot figure
h= figure;
testimage=zeros(72,72);
testimage(1)=-1;
testimage(end)=2;
imageplot=imagesc(testimage);
set(gca,'Units','pixels')
set(gcf,'doublebuffer','off');
% set (gca, 'Position', [73.8 43 72 72]);
set(gca, 'xlimmode','manual',...
           'ylimmode','manual',...
           'zlimmode','manual',...
           'alimmode','manual');
lineplot=line([35 39],[35 39]);
    
%% Start Tracking

set(stimulusplot,'CData',stimulus2);
start(v);
t0 = clock;
j=1;
while elapsedTimetotal<Rectimesec

%% Find fly
j=j+1;
    tic;
frameoriginal = getdata(v,1);
flushdata(v);
frame = imgaussfilt(frameoriginal,1.5);
mask=frame > 100;
mask=bwconvhull(mask);
mask = bwmorph(mask,'shrink',1);
binaryImage=frame < 39;
binaryImage(~mask) = 0;
binaryImage = bwareafilt(binaryImage,1); 

binaryImage=bwmorph(binaryImage,'thicken',3);

frameoriginalthresh = frameoriginal < 78;
frameoriginalthresh(~mask) = 0;
frameoriginalthresh=frameoriginalthresh-binaryImage;
frameoriginalthresh(frameoriginalthresh<0)=0;

props=regionprops(binaryImage,'ConvexHull','Centroid','Perimeter','Orientation','MajorAxisLength');

binaryplot=binaryImage*2;
binaryplot(frameoriginalthresh>0)=-1;

[threshBodyY, thresBodyX] = find(binaryImage == 1);
[threshYSurr, threshXSurr] = find(frameoriginalthresh == 1);

set(imageplot,'CData',binaryplot);
 
if isempty(props)==1
    props = struct('Centroid',[35 35],'ConvexHull',[NaN NaN],'Perimeter',[NaN NaN],'Orientation',[NaN],'MajorAxisLength',[20]);
end
    
%% Center at 0,0
thresBodyX = thresBodyX-props.Centroid(1,1);
threshBodyY = -threshBodyY+props.Centroid(1,2);
threshXSurr = threshXSurr-props.Centroid(1,1);
threshYSurr = -threshYSurr+props.Centroid(1,2);

ang = props.Orientation;  % degrees

%% Align fly body with x-axis
Xshift = 0;
Yshift = 0;
Xrotation =  (thresBodyX-Xshift)*cosd(ang) + (threshBodyY-Yshift)*sind(ang) + Xshift;
Yrotation = -(thresBodyX-Xshift)*sind(ang) + (threshBodyY-Yshift)*cosd(ang) + Yshift;
XrotationSurr =  (threshXSurr-Xshift)*cosd(ang) + (threshYSurr-Yshift)*sind(ang) + Xshift;
YrotationSurr = -(threshXSurr-Xshift)*sind(ang) + (threshYSurr-Yshift)*cosd(ang) + Yshift;

%% Get area per quadrant
Q1=Xrotation(Xrotation>=props.MajorAxisLength/10 & Yrotation>=0);
areaQ1(j)=length(Q1);
Q2=Xrotation(Xrotation<-props.MajorAxisLength/10 & Yrotation>=0);
areaQ2(j)=length(Q2);
Q3=Xrotation(Xrotation<-props.MajorAxisLength/10 & Yrotation<0);
areaQ3(j)=length(Q3);
Q4=Xrotation(Xrotation>=props.MajorAxisLength/10 & Yrotation<0);
areaQ4(j)=length(Q4);

Q1Surr=XrotationSurr(XrotationSurr>=0 & YrotationSurr>=0);
areaQ1Surr(j)=length(Q1Surr);
Q2Surr=XrotationSurr(XrotationSurr<0 & YrotationSurr>=0);
areaQ2Surr(j)=length(Q2Surr);
Q3Surr=XrotationSurr(XrotationSurr<0 & YrotationSurr<0);
areaQ3Surr(j)=length(Q3Surr);
Q4Surr=XrotationSurr(XrotationSurr>=0 & YrotationSurr<0);
areaQ4Surr(j)=length(Q4Surr);

%% Distinguish head from tail
front=(areaQ1(j)+areaQ4(j))-(areaQ2(j)+areaQ3(j));

if front >= 0 
ang=props.Orientation;
else
    if ang <= 0
    ang=props.Orientation+180; 
    else
    ang=props.Orientation-180; 
    end
end


ang(ang<180)=180+ang;
heading(j)=ang;

if j==2
    heading(1)=heading(j);
end

%% Correct implausible heading switches
if abs(rad2deg(angdiff(deg2rad(heading(j)),deg2rad(heading(j-1)))))>150
heading_opposite(1)=heading(j)+180;
heading_opposite(2)=heading(j)-180;
heading(j)=heading_opposite(heading_opposite >= 0 & heading_opposite < 360);
end

%% Detect stop episodes


stops(j)=(max((areaQ2Surr(j)+areaQ3Surr(j)),(areaQ1Surr(j)+areaQ4Surr(j))))>130;

if stops(j)==1
        heading(j)=NaN;
end


% puff if 1 frame stop
if stops(j)==1 && pufferOn==0 
            puffstart= tic; 
            write(arduino1,8,"uint8");
            flush(arduino1);
            pufferOn=1; 
            framepuff(j)=1;
else
        framepuff(j)=0;
end


% Define puff lenth and delete heading for 3s
if pufferOn==1   
    pufftime = toc(puffstart);
    if pufftime>0.1
        write(arduino1,9,"uint8");
        flush(arduino1);
    end
    if pufftime>3
    pufferOn=0;
    end
 heading(j)=NaN;
end

%% Calculate fictive 2D position
if isnan(heading(j))
    Xtraj(j)=Xtraj(j-1);
    Ytraj(j)=Ytraj(j-1);
else
Xtraj(j)=Xtraj(j-1)+(forwardspeed*cos(deg2rad(heading(j))));
Ytraj(j)=Ytraj(j-1)+(forwardspeed*sin(deg2rad(heading(j))));
end

%% Calculate heading line for drawing
x2=props.Centroid(1,1)+(forwardspeed*cos(deg2rad(heading(j))));
y2=props.Centroid(1,2)+(forwardspeed*sin(-deg2rad(heading(j))));
set(lineplot,'XData',[props.Centroid(1,1) x2],'YData',[props.Centroid(1,2) y2])

drawnow limitrate nocallbacks;


timeall(j)= elapsedTime ;  
    frameNr(j) = j;
   fps=1/elapsedTime
 elapsedTimetotal=etime(clock, t0)
 elapsedTime = toc;
% j


end
stop(v)
set(stimulusplot,'CData',blackscreen);
%% Save variables
bur30degcontr100.timeall=timeall(2:j);
bur30degcontr100.heading=heading(2:j);
bur30degcontr100.Xtraj=Xtraj(2:j);
bur30degcontr100.Ytraj=Ytraj(2:j);
bur30degcontr100.stop=stops(2:j);
bur30degcontr100.areaQ1=areaQ1(2:j);
bur30degcontr100.areaQ2=areaQ2(2:j);
bur30degcontr100.areaQ3=areaQ3(2:j);
bur30degcontr100.areaQ4=areaQ4(2:j);
bur30degcontr100.areaQ1Surr=areaQ1Surr(2:j);
bur30degcontr100.areaQ2Surr=areaQ2Surr(2:j);
bur30degcontr100.areaQ3Surr=areaQ3Surr(2:j);
bur30degcontr100.areaQ4Surr=areaQ4Surr(2:j);
bur30degcontr100.framepuff=framepuff(2:j);


clearvars -except v ID bur30degcontr50 bur30degcontr100 Filename1 Filename2 arduino1 pufferOn stimulusplot blackscreen




%% 4 min Buridan 30deg 100% contrast inverted


Filename3 = append(ID,'_30degcontr100inv');
diskLogger = VideoWriter(Filename3, 'Grayscale AVI');
v.DiskLogger = diskLogger;
diskLogger.FrameRate = 90;

% prepare stimulus figure
blackscreen = imread('C:\Users\Behavior_01\Desktop\Stripe Stimuli\black.bmp');
stimulus3 = imread('C:\Users\Behavior_01\Desktop\Stripe Stimuli\30deg\30degstripe 0deg front inverted.bmp');

stimulusfig=figure('MenuBar', 'none', ...
       'ToolBar', 'none')
stimulusplot = imshow(blackscreen);
set(gca,'units','pixels') % set the axes units to pixels
stimulusx = get(gca,'position') % get the position of the axes
set(gcf,'units','pixels') % set the figure units to pixels
stimulusy = get(gcf,'position') % get the figure position
set(gcf,'position',[stimulusy(1) stimulusy(2) stimulusx(3) stimulusx(4)])% set the position of the figure to the length and width of the axes
set(gca,'units','normalized','position',[0 0 1 1]) % set the axes units to pixels
stimulusy = get(gcf,'position') % get the figure position
% need to add pixels for perfect position [1921,953,256,128]
set(gcf,'units','pixels','position',[1921,953,256,128]) % set the axes units to pixels



Rectimesec=240;
downsampledFramerate=60;
predictedframes=Rectimesec*downsampledFramerate*1.5;
forwardspeed=20; % 3cm/frame @60hz = 180cm/s


elapsedTime=0;
elapsedTimetotal=0;
Xtraj(1)=0;
Ytraj(1)=0;
pufferOn=0;
heading=zeros(predictedframes,1);
frameNr=zeros(predictedframes,1); 
areaQ1=zeros(predictedframes,1);
areaQ2=zeros(predictedframes,1);
areaQ3=zeros(predictedframes,1);
areaQ4=zeros(predictedframes,1);
areaQ1Surr=zeros(predictedframes,1);
areaQ2Surr=zeros(predictedframes,1);
areaQ3Surr=zeros(predictedframes,1);
areaQ4Surr=zeros(predictedframes,1);
Xtraj=zeros(predictedframes,1);
Ytraj=zeros(predictedframes,1);
stops=zeros(predictedframes,1);
timeall=zeros(predictedframes,1);
framepuff=zeros(predictedframes,1);

%% Prepare plot figure
h= figure;
testimage=zeros(72,72);
testimage(1)=-1;
testimage(end)=2;
imageplot=imagesc(testimage);
set(gca,'Units','pixels')
set(gcf,'doublebuffer','off');
% set (gca, 'Position', [73.8 43 72 72]);
set(gca, 'xlimmode','manual',...
           'ylimmode','manual',...
           'zlimmode','manual',...
           'alimmode','manual');
lineplot=line([35 39],[35 39]);
    
%% Start Tracking

set(stimulusplot,'CData',stimulus3);
start(v);
t0 = clock;
j=1;
while elapsedTimetotal<Rectimesec

%% Find fly
j=j+1;
    tic;
frameoriginal = getdata(v,1);
flushdata(v);
frame = imgaussfilt(frameoriginal,1.5);
mask=frame > 100;
mask=bwconvhull(mask);
mask = bwmorph(mask,'shrink',1);
binaryImage=frame < 39;
binaryImage(~mask) = 0;
binaryImage = bwareafilt(binaryImage,1); 

binaryImage=bwmorph(binaryImage,'thicken',3);

frameoriginalthresh = frameoriginal < 78;
frameoriginalthresh(~mask) = 0;
frameoriginalthresh=frameoriginalthresh-binaryImage;
frameoriginalthresh(frameoriginalthresh<0)=0;

props=regionprops(binaryImage,'ConvexHull','Centroid','Perimeter','Orientation','MajorAxisLength');

binaryplot=binaryImage*2;
binaryplot(frameoriginalthresh>0)=-1;

[threshBodyY, thresBodyX] = find(binaryImage == 1);
[threshYSurr, threshXSurr] = find(frameoriginalthresh == 1);

set(imageplot,'CData',binaryplot);
 
if isempty(props)==1
    props = struct('Centroid',[35 35],'ConvexHull',[NaN NaN],'Perimeter',[NaN NaN],'Orientation',[NaN],'MajorAxisLength',[20]);
end
    
%% Center at 0,0
thresBodyX = thresBodyX-props.Centroid(1,1);
threshBodyY = -threshBodyY+props.Centroid(1,2);
threshXSurr = threshXSurr-props.Centroid(1,1);
threshYSurr = -threshYSurr+props.Centroid(1,2);

ang = props.Orientation;  % degrees

%% Align fly body with x-axis
Xshift = 0;
Yshift = 0;
Xrotation =  (thresBodyX-Xshift)*cosd(ang) + (threshBodyY-Yshift)*sind(ang) + Xshift;
Yrotation = -(thresBodyX-Xshift)*sind(ang) + (threshBodyY-Yshift)*cosd(ang) + Yshift;
XrotationSurr =  (threshXSurr-Xshift)*cosd(ang) + (threshYSurr-Yshift)*sind(ang) + Xshift;
YrotationSurr = -(threshXSurr-Xshift)*sind(ang) + (threshYSurr-Yshift)*cosd(ang) + Yshift;

%% Get area per quadrant
Q1=Xrotation(Xrotation>=props.MajorAxisLength/10 & Yrotation>=0);
areaQ1(j)=length(Q1);
Q2=Xrotation(Xrotation<-props.MajorAxisLength/10 & Yrotation>=0);
areaQ2(j)=length(Q2);
Q3=Xrotation(Xrotation<-props.MajorAxisLength/10 & Yrotation<0);
areaQ3(j)=length(Q3);
Q4=Xrotation(Xrotation>=props.MajorAxisLength/10 & Yrotation<0);
areaQ4(j)=length(Q4);

Q1Surr=XrotationSurr(XrotationSurr>=0 & YrotationSurr>=0);
areaQ1Surr(j)=length(Q1Surr);
Q2Surr=XrotationSurr(XrotationSurr<0 & YrotationSurr>=0);
areaQ2Surr(j)=length(Q2Surr);
Q3Surr=XrotationSurr(XrotationSurr<0 & YrotationSurr<0);
areaQ3Surr(j)=length(Q3Surr);
Q4Surr=XrotationSurr(XrotationSurr>=0 & YrotationSurr<0);
areaQ4Surr(j)=length(Q4Surr);

%% Distinguish head from tail
front=(areaQ1(j)+areaQ4(j))-(areaQ2(j)+areaQ3(j));

if front >= 0 
ang=props.Orientation;
else
    if ang <= 0
    ang=props.Orientation+180; 
    else
    ang=props.Orientation-180; 
    end
end


ang(ang<180)=180+ang;
heading(j)=ang;

if j==2
    heading(1)=heading(j);
end

%% Correct implausible heading switches
if abs(rad2deg(angdiff(deg2rad(heading(j)),deg2rad(heading(j-1)))))>150
heading_opposite(1)=heading(j)+180;
heading_opposite(2)=heading(j)-180;
heading(j)=heading_opposite(heading_opposite >= 0 & heading_opposite < 360);
end

%% Detect stop episodes


stops(j)=(max((areaQ2Surr(j)+areaQ3Surr(j)),(areaQ1Surr(j)+areaQ4Surr(j))))>130;

if stops(j)==1
        heading(j)=NaN;
end


% puff if 1 frame stop
if stops(j)==1 && pufferOn==0 
            puffstart= tic; 
            write(arduino1,8,"uint8");
            flush(arduino1);
            pufferOn=1; 
            framepuff(j)=1;
else
        framepuff(j)=0;
end


% Define puff lenth and delete heading for 3s
if pufferOn==1   
    pufftime = toc(puffstart);
    if pufftime>0.1
        write(arduino1,9,"uint8");
        flush(arduino1);
    end
    if pufftime>3
    pufferOn=0;
    end
 heading(j)=NaN;
end

%% Calculate fictive 2D position
if isnan(heading(j))
    Xtraj(j)=Xtraj(j-1);
    Ytraj(j)=Ytraj(j-1);
else
Xtraj(j)=Xtraj(j-1)+(forwardspeed*cos(deg2rad(heading(j))));
Ytraj(j)=Ytraj(j-1)+(forwardspeed*sin(deg2rad(heading(j))));
end

%% Calculate heading line for drawing
x2=props.Centroid(1,1)+(forwardspeed*cos(deg2rad(heading(j))));
y2=props.Centroid(1,2)+(forwardspeed*sin(-deg2rad(heading(j))));
set(lineplot,'XData',[props.Centroid(1,1) x2],'YData',[props.Centroid(1,2) y2])

drawnow limitrate nocallbacks;


timeall(j)= elapsedTime ;  
    frameNr(j) = j;
   fps=1/elapsedTime
 elapsedTimetotal=etime(clock, t0)
 elapsedTime = toc;
% j


end
stop(v)
set(stimulusplot,'CData',blackscreen);
%% Save variables
bur30degcontr100inv.timeall=timeall(2:j);
bur30degcontr100inv.heading=heading(2:j);
bur30degcontr100inv.Xtraj=Xtraj(2:j);
bur30degcontr100inv.Ytraj=Ytraj(2:j);
bur30degcontr100inv.stop=stops(2:j);
bur30degcontr100inv.areaQ1=areaQ1(2:j);
bur30degcontr100inv.areaQ2=areaQ2(2:j);
bur30degcontr100inv.areaQ3=areaQ3(2:j);
bur30degcontr100inv.areaQ4=areaQ4(2:j);
bur30degcontr100inv.areaQ1Surr=areaQ1Surr(2:j);
bur30degcontr100inv.areaQ2Surr=areaQ2Surr(2:j);
bur30degcontr100inv.areaQ3Surr=areaQ3Surr(2:j);
bur30degcontr100inv.areaQ4Surr=areaQ4Surr(2:j);
bur30degcontr100inv.framepuff=framepuff(2:j);


image.binaryplot=binaryplot;
image.binaryImage=binaryImage;
image.frameoriginal=frameoriginal;
image.frameoriginalthresh=frameoriginalthresh;
image.frameoriginal=frameoriginal;
image.frame=frame;
image.mask=mask;

clearvars -except v ID bur30degcontr50 bur30degcontr100 bur30degcontr100inv image Filename1 Filename2 Filename3 pufferOn stimulusplot blackscreen


save(Filename1)

close all





figure('units','pixel','outerposition',[672   686   576   377]);
% figure
subplot(1,3,1);
polarhistogram(deg2rad(bur30degcontr50.heading),100);
title('bur30degcontr50');
subplot(1,3,2);
polarhistogram(deg2rad(bur30degcontr100.heading),100);
title('bur30degcontr100');
subplot(1,3,3);
polarhistogram(deg2rad(bur30degcontr100inv.heading),100);
title('bur30degcontr100inv');
sgtitle(ID);
saveas(gcf,[ ID '_overview.png']);
close all
